
/*:
 ## WWDC 2018 Submission
 ### A Revolutionary, Interactive Playground
 ### By Jonathon Derr */

/*:
 - important:
 Make Sure Markup is Rendered and Timeline is shown!
 */

/*:
 ## Instructions
 ### Shoot or Dodge Pellets without dying
 ### Each pellet will damage you 10 health
 */


/*:
 - important:
 On start up, does xcode give an error that it can't identify the function: start?
 This is normal, and I cant get rid of it. Just simply wait for it to keep running and it will fix itself.
 */



import Foundation
import Cocoa
import PlaygroundSupport

/*:
 - experiment:
 Try changing the color variable.
 */
let color = #colorLiteral(red: 0.245803833, green: 0.2545180321, blue: 0.2892864048, alpha: 1)

/*:
 - Note:
 You can change the color bar with ease if you show the touchbar. Do this by
 going to Window > Show Touch Bar
 */

/*:
 - experiment:
 Try changing the speed variable. What does it do?
 */
public let shaderSpeed = 1.0

/*:
 - Note:
 Want to play other levels without having to complete one? After your first run through of a game, A new menu on the start screen will appear. With this, you can select other levels.
 */

/*:
 - Note:
    Want to create your own levels? Currently, there is a beta function to do this on the level select menu, at the end of the levels. Do create your own. hit the + button, edit place down your pellets, and then hit back. When you go to test your level in the level select screen, it will play that sequence!
 */



let viewController = PlaygroundViewController()
viewController.view = start(color: color, vc: viewController, speed: shaderSpeed)
  PlaygroundPage.current.liveView = viewController.view

PlaygroundPage.current.needsIndefiniteExecution = true

