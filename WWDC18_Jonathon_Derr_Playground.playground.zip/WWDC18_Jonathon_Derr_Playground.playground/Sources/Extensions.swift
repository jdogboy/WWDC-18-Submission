import Foundation
import AppKit


extension String {
    func width(height: CGFloat, font: NSFont) -> CGFloat{
        let rect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: rect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        
        return ceil(boundingBox.width)
    }
}
