import Foundation
import SpriteKit

class Level {
    var boss: Boss?
    var sequences: [Sequence] = []
    var screenshot: NSImage? = #imageLiteral(resourceName: "noImageFound.png")
    var name = ""
}

class Sequence {
    var action: ()->Void = {}
    var message: String = ""
    var duration: Float = 0.0
    var messageDuration: Float = 0.0
    var background: Background?
    
    var name: String = ""
    
    var storedPellets: [Pellet] = []
    
    //QuickCuts are cuts that end the sequence earlier than nescessary if needed
    var quickCut: ()->Void = {}
    var lengthenTimeCheck: ()->Void = {}
}

class Boss {
    var health = 1000.0
    var attackDamage = 20.0
    var strength = 50.0
}

class Background {
    var shaderBack: SKShader? = shaders[2]
    init(shader: SKShader){
        shaderBack = shader
    }
    init(source: String, uniforms: [SKUniform]) {
        let customShader = SKShader(fileNamed: source)
            customShader.uniforms = uniforms
        shaderBack = customShader
    }
}
