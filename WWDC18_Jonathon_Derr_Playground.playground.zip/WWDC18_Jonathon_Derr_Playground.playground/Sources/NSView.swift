

import Foundation
import SpriteKit
import Darwin
import AppKit

public var isAnimating = false

public var VC: NSViewController!

public var levelIndexCurrent = 0

public var shaderSpeed = 1.0

var sequencesFromUser: [Sequence] = []


extension NSTouchBarItem.Identifier {
    static let color = NSTouchBarItem.Identifier("com.TouchBarCatalog.TouchBarItem.color")
    static let text = NSTouchBarItem.Identifier("com.TouchBarCatalog.TouchBarItem.text")
    static let stroke = NSTouchBarItem.Identifier("com.TouchBarCatalog.TouchBarItem.stroke")
}

extension NSTouchBar.CustomizationIdentifier {
     static let colorPickerBar = NSTouchBar.CustomizationIdentifier("com.TouchBarCatalog.colorPickerBar")
}


public class PlaygroundViewController: NSViewController, NSTouchBarDelegate {
    
    public func getLocation() -> NSPoint{
        let window = self.view.window!
        return window.mouseLocationOutsideOfEventStream
        
        
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    public override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
   public override func makeTouchBar() -> NSTouchBar? {
        let touchBar = NSTouchBar()
        touchBar.delegate = self
    
        touchBar.customizationIdentifier = .colorPickerBar
    
        touchBar.defaultItemIdentifiers = [.color]
        touchBar.customizationAllowedItemIdentifiers = [.color]
        touchBar.principalItemIdentifier = .color
        return touchBar
    }
    
    public func touchBar(_ touchBar: NSTouchBar, makeItemForIdentifier identifier:
        NSTouchBarItem.Identifier) -> NSTouchBarItem? {
        
        let colorPicker: NSColorPickerTouchBarItem

        switch identifier {
        case NSTouchBarItem.Identifier.color:
           colorPicker = NSColorPickerTouchBarItem.colorPicker(withIdentifier: identifier)
        default:
            return nil
        }
        
        colorPicker.customizationLabel = NSLocalizedString("Yeet", comment: "Or not")
        colorPicker.target = self
        colorPicker.action = #selector(changeBackColor(_:))
        return colorPicker
    }
    
    @objc
    public func changeBackColor(_ colorPicker: NSColorPickerTouchBarItem){
        globalChangeBackColor(color: colorPicker.color)
        let ciColor = CIColor(color: colorPicker.color)
        updateCircleColorAttributes(color: ciColor!)
        mainColor = ciColor!
    }
    @objc
    public func left(){
        if levelIndexCurrent > 0{

        if !isAnimating {
            slideLevelDisplayLeft(viewController: self)
            isAnimating = true
        }
        }
    }
    
    @objc
    public func right(){
        if levelIndexCurrent <= levelsOnScreen.count - 1{
            if !isAnimating {
                slideLevelDisplayRight(viewController: self)
                isAnimating = true
            }
        }
    }
    
    @objc
    public func play() {
        hideLevelViewToStart()
        playLevel()
    }
    
    @objc
    public func endlessMode() {
        
    }
    
    @objc
    public func levelSelect() {
        showLevelView()
    }
    
    @objc
    public func cancelLevelMenu(){
        hideLevelViewToStart()
    }
    
    @objc
    public func nextLevel(){
        nextLevelButtonAction()
    }
    
    @objc
    public func replayLevel(){
        replayLevelButtonAction()
    }
    
    @objc func toMainScreen(){
        toMainScreenButtonAction()
    }
    
    @objc func playUserCreatedLevel(){
        
    }
    
    @objc func toSequenceEditorButton() {
        toSequenceEditor()
    }
    
    @objc func backFromEditor(){
        
        scene.onStartScreen = true
        
        let seq = Sequence()
        
        seq.storedPellets = currentSequencePellets
        
        seq.action = {
            for pellet in seq.storedPellets{
                
                scene.actionNode.run(SKAction.wait(forDuration: 0.5), completion: {
                    scene.addChild(pellet)
                    pellet.physicsBody?.isDynamic = true
                    pellets[pellet.index] = pellet
                })
               
            }
        }
        
        seq.name = "tested"
        
        
        seq.quickCut = {
                if pellets.isEmpty {
                scene.quickCut = {}
                if !isResetting{
                    scene.nextAction()
                }
            }
        }
        sequencesFromUser.append(seq)
        
        for pellet in currentSequencePellets{
            pellet.removeFromParent()
        }
        
        currentSequencePellets.removeAll()
        
        hideEditor()
    }
    
    @objc func testCreatedLevel() {
        
        if !sequencesFromUser.isEmpty {
            hideLevelViewToStart()
            
            let createdLevel = Level()
            
            createdLevel.sequences = sequencesFromUser
            
            scene.playLevel(level: createdLevel)
        }
    }
    


}

public func globalChangeBackColor(color: NSColor){
    scene.colorBack.fillColor = color
    scene.circleBack.fillColor = color
}

 let scene = Scene(size: CGSize(width: WIDTH, height: HEIGHT))


let visualEffectsView = NSVisualEffectView(frame: NSRect(x: WIDTH/2 - 150, y: 75, width: 300, height: 50))




let introLabel = NSTextField(string: "Drag or Click the Screen to Start")

let levelDisplay = NSView(frame: NSRect(x: 0, y: HEIGHT, width: WIDTH, height: HEIGHT))

var currentLevelDisplay = NSView()
var leftLevelDisplay = NSView()
var rightLevelDisplay = NSView()
var holderView = NSView()

let menuStartDisplay = NSVisualEffectView(frame: NSRect(x: WIDTH/2 - 150, y: 75, width: 300, height: 50))


var winScreen = NSView(frame: NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT))
var lossScreen = NSView(frame: NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT))


var scoreLabel = NSTextField(string: "Score: 100")
var healthLabel = NSTextField(string: "Final Health: 100")

var scoreLossLabel = NSTextField(string: "Score: 100")
var healthLossLabel = NSTextField(string: "Final Health: 100")

var editorHud =  NSView(frame: NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT))



public func start(color: NSColor, vc: PlaygroundViewController, speed: Double) -> NSView{
    
    shaderSpeed = speed
    
    VC = vc
    
    let WIDTH = 640
    let HEIGHT = 480
    
    
    
    let skView = SKView(frame: CGRect(x: 0, y: 0, width: WIDTH, height: HEIGHT))
    //skView.showsFPS = true
//    skView.showsPhysics = true
   // skView.showsNodeCount = true
    scene.physicsWorld.gravity = CGVector()
    scene.scaleMode = .aspectFit
    scene.colorBack.fillColor = color
    skView.presentScene(scene)
    
    
    let options = [NSTrackingArea.Options.mouseMoved, NSTrackingArea.Options.activeInKeyWindow, NSTrackingArea.Options.activeAlways, NSTrackingArea.Options.inVisibleRect, ] as NSTrackingArea.Options
    let tracker = NSTrackingArea(rect: skView.frame, options: options, owner: skView, userInfo: nil)
    skView.addTrackingArea(tracker)
    
    let displayView = NSView(frame: CGRect(x: 0, y: 0, width: WIDTH, height: HEIGHT))
    
    
    displayView.addSubview(skView)
    
    
  
    visualEffectsView.blendingMode = .withinWindow
    visualEffectsView.material = .dark
    visualEffectsView.wantsLayer = true
    visualEffectsView.layer?.cornerRadius = 15
    visualEffectsView.layerContentsRedrawPolicy = .onSetNeedsDisplay
    displayView.addSubview(visualEffectsView)
    
    menuStartDisplay.blendingMode = .withinWindow
    menuStartDisplay.material = .dark
    menuStartDisplay.wantsLayer = true
    menuStartDisplay.layer?.cornerRadius = 15
    menuStartDisplay.layerContentsRedrawPolicy = .onSetNeedsDisplay
    displayView.addSubview(menuStartDisplay)
    
    let endlessModeButton = NSButton(title: "Endless", target: vc, action: #selector(vc.endlessMode))
    endlessModeButton.frame = NSRect(x: 0, y: 0, width: menuStartDisplay.frame.width/2 - 5, height: 50)
    endlessModeButton.bezelStyle = .texturedSquare
    endlessModeButton.isBordered = false
    endlessModeButton.wantsLayer = true
    endlessModeButton.layer?.cornerRadius = 15
    endlessModeButton.layer?.backgroundColor = #colorLiteral(red: 0.9961728454, green: 0.9902502894, blue: 1, alpha: 1)
    endlessModeButton.alphaValue = 0.7
    
   // menuStartDisplay.addSubview(endlessModeButton)
    
    let levelSelectButton = NSButton(title: "Select Level", target: vc, action: #selector(vc.levelSelect))
    levelSelectButton.frame = NSRect(x: (menuStartDisplay.frame.width/2) - ((menuStartDisplay.frame.width/2 - 5) / 2), y: 0, width:
        menuStartDisplay.frame.width/2 - 5, height: 50)
    levelSelectButton.bezelStyle = .texturedSquare
    levelSelectButton.isBordered = false
    levelSelectButton.wantsLayer = true
    levelSelectButton.layer?.cornerRadius = 15
    levelSelectButton.alphaValue = 0.7
    levelSelectButton.layer?.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
    
    if let mutableAttributedTitle = levelSelectButton.attributedTitle.mutableCopy() as? NSMutableAttributedString {
        mutableAttributedTitle.addAttribute(.foregroundColor, value: NSColor.white, range: NSRange(location: 0, length: mutableAttributedTitle.length))
        mutableAttributedTitle.addAttribute(.font, value: NSFont(name: "Avenir", size: 15), range: NSRange(location: 0, length: mutableAttributedTitle.length))
        levelSelectButton.attributedTitle = mutableAttributedTitle
    }
    
    menuStartDisplay.addSubview(levelSelectButton)
    
    introLabel.frame = NSRect(x: 0, y: 0, width: 300, height: 38)
    introLabel.isEditable = false
    introLabel.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    introLabel.drawsBackground = false
    introLabel.isBezeled = false
    introLabel.alignment = .center
    introLabel.font = NSFont.systemFont(ofSize: 20)
    visualEffectsView.addSubview(introLabel)
    
    levelDisplay.wantsLayer = true
    levelDisplay.layerContentsRedrawPolicy = .onSetNeedsDisplay
    //startScreen.layer?.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    
    levelDisplay.alphaValue = 0
    
    
    displayView.addSubview(levelDisplay)
    
    currentLevelDisplay = createLevelDisplay(frame: NSRect(x: (WIDTH/2) - 150, y: (HEIGHT/2) - 150, width: 300, height: 300), vc: vc, level: levelsOnScreen[levelIndexCurrent])
    levelDisplay.addSubview(currentLevelDisplay)
    
    leftLevelDisplay  = createLevelDisplay(frame: NSRect(x: 50, y: currentLevelDisplay.frame.minY, width: 150, height: 300), vc: vc,  level: levelsOnScreen[levelIndexCurrent])
    leftLevelDisplay.alphaValue = 0
    levelDisplay.addSubview(leftLevelDisplay)
    
    rightLevelDisplay = createLevelDisplay(frame: NSRect(x: WIDTH - 50 - 150, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: vc,  level: levelsOnScreen[levelIndexCurrent + 1])
    rightLevelDisplay.alphaValue = 0
    levelDisplay.addSubview(rightLevelDisplay)

    
    
    let arrowLeftDisplayBack = NSVisualEffectView(frame: NSRect(x: 25, y: (HEIGHT/2) - 25, width: 50, height: 50))
    arrowLeftDisplayBack.blendingMode = .withinWindow
    arrowLeftDisplayBack.material = .dark
    arrowLeftDisplayBack.wantsLayer = true
    arrowLeftDisplayBack.layer?.cornerRadius = 15
    arrowLeftDisplayBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplay.addSubview(arrowLeftDisplayBack)
    
    let leftBImage = #imageLiteral(resourceName: "left.png")
    let leftButton = NSButton(title: "", image: leftBImage, target: vc, action: #selector(vc.left))
    leftButton.imagePosition = .imageOnly
    leftButton.image?.size = NSSize(width: 35, height: 35)
    leftButton.isBordered = false
    leftButton.frame = NSRect(x: 0, y: 0, width: 50, height: 50)
    arrowLeftDisplayBack.addSubview(leftButton)
    
    
    let arrowRightDisplayBack = NSVisualEffectView(frame: NSRect(x: WIDTH - 75, y: (HEIGHT/2) - 25, width: 50, height: 50))
    arrowRightDisplayBack.blendingMode = .withinWindow
    arrowRightDisplayBack.material = .dark
    arrowRightDisplayBack.wantsLayer = true
    arrowRightDisplayBack.layer?.cornerRadius = 15
    arrowRightDisplayBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplay.addSubview(arrowRightDisplayBack)
    
    let rightBImage = #imageLiteral(resourceName: "right.png")
    let rightButton = NSButton(title: "", image: rightBImage, target: vc, action: #selector(vc.right))
    rightButton.imagePosition = .imageOnly
    rightButton.image?.size = NSSize(width: 35, height: 35)
    rightButton.isBordered = false
    rightButton.frame = NSRect(x: 0, y: 0, width: 50, height: 50)
    arrowRightDisplayBack.addSubview(rightButton)
    
    let cancelDisplayBack = NSVisualEffectView(frame: NSRect(x: WIDTH/2 - 75, y: 25, width: 150, height: 40))
    cancelDisplayBack.blendingMode = .withinWindow
    cancelDisplayBack.material = .dark
    cancelDisplayBack.wantsLayer = true
    cancelDisplayBack.layer?.cornerRadius = 7
    cancelDisplayBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplay.addSubview(cancelDisplayBack)
    
    let cancelButton = NSButton(title: "Cancel", image: rightBImage, target: vc, action: #selector(vc.cancelLevelMenu))
    cancelButton.imagePosition = .noImage
    cancelButton.isBordered = false
    cancelButton.frame = NSRect(x: 0, y: 3, width: 150, height: 40)
    cancelDisplayBack.addSubview(cancelButton)
    
    if let mutableAttributedTitle = cancelButton.attributedTitle.mutableCopy() as? NSMutableAttributedString {
        mutableAttributedTitle.addAttribute(.foregroundColor, value: NSColor.white, range: NSRange(location: 0, length: mutableAttributedTitle.length))
        mutableAttributedTitle.addAttribute(.font, value: NSFont(name: "Avenir", size: 17), range: NSRange(location: 0, length: mutableAttributedTitle.length))
        cancelButton.attributedTitle = mutableAttributedTitle
    }
    
    
    //Win Screen
    
    winScreen.wantsLayer = true
    winScreen.alphaValue = 0
    displayView.addSubview(winScreen)
    
    let statsBack = NSVisualEffectView(frame: NSRect(x: WIDTH/2 - 150, y: HEIGHT/2 - 100, width: 300, height: 200))
    statsBack.blendingMode = .withinWindow
    statsBack.material = .dark
    statsBack.wantsLayer = true
    statsBack.layer?.cornerRadius = 15
    statsBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    winScreen.addSubview(statsBack)
    
    let winLabel = NSTextField(string: "Level Complete!")
    winLabel.frame = NSRect(x: 0, y: 200 - 50, width: 300, height: 38)
    winLabel.isEditable = false
    winLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    winLabel.drawsBackground = false
    winLabel.isBezeled = false
    winLabel.alignment = .center
    winLabel.font = NSFont.systemFont(ofSize: 20)
    statsBack.addSubview(winLabel)
    
    scoreLabel.frame = NSRect(x: 0, y: 200 - 50 - 38, width: 300, height: 38)
    scoreLabel.font = NSFont(name: "Avenir", size: 17)
    scoreLabel.isEditable = false
    scoreLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    scoreLabel.drawsBackground = false
    scoreLabel.isBezeled = false
    scoreLabel.alignment = .center
    scoreLabel.font = NSFont.systemFont(ofSize: 20)
    statsBack.addSubview(scoreLabel)
    
    healthLabel.frame = NSRect(x: 0, y: 200 - 50 - 38 * 2, width: 300, height: 38)
    healthLabel.font = NSFont(name: "Avenir", size: 17)
    healthLabel.isEditable = false
    healthLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    healthLabel.drawsBackground = false
    healthLabel.isBezeled = false
    healthLabel.alignment = .center
    healthLabel.font = NSFont.systemFont(ofSize: 20)
    statsBack.addSubview(healthLabel)
    
    let mainScreenButton = NSButton(title: "Main Screen", target: vc, action: #selector(vc.toMainScreen))
    mainScreenButton.frame = NSRect(x: 0, y: 0, width: menuStartDisplay.frame.width/2 - 5, height: 50)
    mainScreenButton.bezelStyle = .texturedSquare
    mainScreenButton.isBordered = false
    mainScreenButton.wantsLayer = true
    mainScreenButton.layer?.cornerRadius = 15
    mainScreenButton.layer?.backgroundColor = #colorLiteral(red: 0.9961728454, green: 0.9902502894, blue: 1, alpha: 1)
    mainScreenButton.alphaValue = 0.7
    
    statsBack.addSubview(mainScreenButton)
    
    let nextLevelButton = NSButton(title: "Next Level", target: vc, action: #selector(vc.nextLevel))
    nextLevelButton.frame = NSRect(x: 5 + statsBack.frame.width/2, y: 0, width:
        statsBack.frame.width/2 - 5, height: 50)
    nextLevelButton.bezelStyle = .texturedSquare
    nextLevelButton.isBordered = false
    nextLevelButton.wantsLayer = true
    nextLevelButton.layer?.cornerRadius = 15
    nextLevelButton.alphaValue = 0.7
    nextLevelButton.layer?.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
    
    if let mutableAttributedTitle = nextLevelButton.attributedTitle.mutableCopy() as? NSMutableAttributedString {
        mutableAttributedTitle.addAttribute(.foregroundColor, value: NSColor.white, range: NSRange(location: 0, length: mutableAttributedTitle.length))
        mutableAttributedTitle.addAttribute(.font, value: NSFont(name: "Avenir", size: 15), range: NSRange(location: 0, length: mutableAttributedTitle.length))
        nextLevelButton.attributedTitle = mutableAttributedTitle
    }
    statsBack.addSubview(nextLevelButton)
    
    
    //Win Screen
    
    lossScreen.wantsLayer = true
    lossScreen.alphaValue = 0
    displayView.addSubview(lossScreen)
    
    let lossBack = NSVisualEffectView(frame: NSRect(x: WIDTH/2 - 150, y: HEIGHT/2 - 100, width: 300, height: 200))
    lossBack.blendingMode = .withinWindow
    lossBack.material = .dark
    lossBack.wantsLayer = true
    lossBack.layer?.cornerRadius = 15
    lossBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    lossScreen.addSubview(lossBack)
    
    let lossLabel = NSTextField(string: "Level Failed... :(")
    lossLabel.frame = NSRect(x: 0, y: 200 - 50, width: 300, height: 38)
    lossLabel.isEditable = false
    lossLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    lossLabel.drawsBackground = false
    lossLabel.isBezeled = false
    lossLabel.alignment = .center
    lossLabel.font = NSFont.systemFont(ofSize: 20)
    lossBack.addSubview(lossLabel)
    
    scoreLossLabel.frame = NSRect(x: 0, y: 200 - 50 - 38, width: 300, height: 38)
    scoreLossLabel.font = NSFont(name: "Avenir", size: 17)
    scoreLossLabel.isEditable = false
    scoreLossLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    scoreLossLabel.drawsBackground = false
    scoreLossLabel.isBezeled = false
    scoreLossLabel.alignment = .center
    scoreLossLabel.font = NSFont.systemFont(ofSize: 20)
    lossBack.addSubview(scoreLossLabel)
    
    healthLossLabel.frame = NSRect(x: 0, y: 200 - 50 - 38 * 2, width: 300, height: 38)
    healthLossLabel.font = NSFont(name: "Avenir", size: 17)
    healthLossLabel.isEditable = false
    healthLossLabel.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    healthLossLabel.drawsBackground = false
    healthLossLabel.isBezeled = false
    healthLossLabel.alignment = .center
    healthLossLabel.font = NSFont.systemFont(ofSize: 20)
    lossBack.addSubview(healthLossLabel)
    
    let mainScreenButtonLoss = NSButton(title: "Main Screen", target: vc, action: #selector(vc.toMainScreen))
    mainScreenButtonLoss.frame = NSRect(x: 0, y: 0, width: menuStartDisplay.frame.width/2 - 5, height: 50)
    mainScreenButtonLoss.bezelStyle = .texturedSquare
    mainScreenButtonLoss.isBordered = false
    mainScreenButtonLoss.wantsLayer = true
    mainScreenButtonLoss.layer?.cornerRadius = 15
    mainScreenButtonLoss.layer?.backgroundColor = #colorLiteral(red: 0.9961728454, green: 0.9902502894, blue: 1, alpha: 1)
    mainScreenButtonLoss.alphaValue = 0.7
    
    lossBack.addSubview(mainScreenButtonLoss)
    
    let nextLevelButtonLoss = NSButton(title: "Replay", target: vc, action: #selector(vc.replayLevel))
    nextLevelButtonLoss.frame = NSRect(x: 5 + statsBack.frame.width/2, y: 0, width:
        statsBack.frame.width/2 - 5, height: 50)
    nextLevelButtonLoss.bezelStyle = .texturedSquare
    nextLevelButtonLoss.isBordered = false
    nextLevelButtonLoss.wantsLayer = true
    nextLevelButtonLoss.layer?.cornerRadius = 15
    nextLevelButtonLoss.alphaValue = 0.7
    nextLevelButtonLoss.layer?.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
    
    if let mutableAttributedTitle = nextLevelButtonLoss.attributedTitle.mutableCopy() as? NSMutableAttributedString {
        mutableAttributedTitle.addAttribute(.foregroundColor, value: NSColor.white, range: NSRange(location: 0, length: mutableAttributedTitle.length))
        mutableAttributedTitle.addAttribute(.font, value: NSFont(name: "Avenir", size: 15), range: NSRange(location: 0, length: mutableAttributedTitle.length))
        nextLevelButtonLoss.attributedTitle = mutableAttributedTitle
    }
    lossBack.addSubview(nextLevelButtonLoss)
   
    hideDisplayMenu()
    
    editorHud.wantsLayer = true
    editorHud.alphaValue = 0
    displayView.addSubview(editorHud)
    
    let backButtonBack = NSVisualEffectView(frame: NSRect(x: 40, y: 10, width: 40, height: 40))
    
    backButtonBack.blendingMode = .withinWindow
    backButtonBack.material = .dark
    
    backButtonBack.wantsLayer = true
    backButtonBack.layer?.cornerRadius = 15
    backButtonBack.wantsLayer = true
    backButtonBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    
    editorHud.addSubview(backButtonBack)
    
    let backButton = NSButton(title: "<", target: vc, action: #selector(vc.backFromEditor))
    backButton.image = #imageLiteral(resourceName: "left.png")
    backButton.imagePosition = .imageOnly
    backButton.frame = NSRect(x: 0, y: 0, width: 40, height: 40)
    backButton.isBordered = false
    
    
    backButtonBack.addSubview(backButton)

    setMessage(message: "Click or Drag the Screen to start", duration: 0)
    scene.currentMessage = "Click or Drag the Screen to start"
    
    
    return displayView
}

 func createLevelDisplay(frame: NSRect, vc: PlaygroundViewController, level: Level) -> NSView {
    let levelDisplayBack = NSVisualEffectView(frame: frame)
    levelDisplayBack.blendingMode = .withinWindow
    levelDisplayBack.material = .dark
    levelDisplayBack.wantsLayer = true
    levelDisplayBack.layer?.cornerRadius = 15
    levelDisplayBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    
    let levelTitle = NSTextField(string: level.name)
    levelTitle.frame = NSRect(x: 0, y: 300 - 50, width: 300, height: 38)
    levelTitle.isEditable = false
    levelTitle.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    levelTitle.drawsBackground = false
    levelTitle.isBezeled = false
    levelTitle.alignment = .center
    levelTitle.font = NSFont.systemFont(ofSize: 20)
    levelDisplayBack.addSubview(levelTitle)
    
    let levelImage = NSImageView(image: level.screenshot!)
    levelImage.frame = NSRect(x: 50, y: 300 - 150 - 60 , width: 200, height: 150)
    levelImage.wantsLayer = true
    levelImage.layer?.cornerRadius = 7
    
    let shadow = NSShadow()
    shadow.shadowBlurRadius = 10
    shadow.shadowOffset = NSSize(width: 0, height: -4)
    shadow.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    levelImage.shadow = shadow
    levelDisplayBack.addSubview(levelImage)
    
    let playButton = NSButton(title: "", image: #imageLiteral(resourceName: "playIcon.png"), target: vc, action: #selector(vc.play))
    playButton.imagePosition = .imageOnly
    playButton.image?.size = NSSize(width: 50, height: 50)
    playButton.isBordered = false
    playButton.frame = NSRect(x: 125, y:  15, width: 50, height: 50)
    playButton.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplayBack.addSubview(playButton)
    
    return levelDisplayBack
    
}

func createLevelDisplayAction(frame: NSRect, vc: PlaygroundViewController) -> NSView {
    let levelDisplayBack = NSVisualEffectView(frame: frame)
    levelDisplayBack.blendingMode = .withinWindow
    levelDisplayBack.material = .dark
    levelDisplayBack.wantsLayer = true
    levelDisplayBack.layer?.cornerRadius = 15
    levelDisplayBack.layerContentsRedrawPolicy = .onSetNeedsDisplay
    
    var levelTitle = NSTextField(string: "Create New Level")
    levelTitle.frame = NSRect(x: 0, y: 300 - 50, width: 300, height: 38)
    levelTitle.isEditable = false
    levelTitle.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    levelTitle.drawsBackground = false
    levelTitle.isBezeled = false
    levelTitle.alignment = .center
    levelTitle.font = NSFont.systemFont(ofSize: 20)
    levelDisplayBack.addSubview(levelTitle)
    
    var sequenceEditorTitle = NSTextField(string: "Sequence Editor")
    sequenceEditorTitle.frame = NSRect(x: 10, y: 300 - 50 - 40, width: 300, height: 38)
    sequenceEditorTitle.isEditable = false
    sequenceEditorTitle.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    sequenceEditorTitle.drawsBackground = false
    sequenceEditorTitle.isBezeled = false
    sequenceEditorTitle.alignment = .left
    sequenceEditorTitle.font = NSFont.systemFont(ofSize: 20)
    levelDisplayBack.addSubview(sequenceEditorTitle)
    
    let emptySequenceButton = NSButton(title: "", image: #imageLiteral(resourceName: "newSequence.png"), target: vc, action: #selector(vc.toSequenceEditorButton))
    emptySequenceButton.imagePosition = .imageOnly
    emptySequenceButton.image?.size = NSSize(width: 50, height: 50)
    emptySequenceButton.isBordered = false
    emptySequenceButton.frame = NSRect(x: 125, y:  300 - 50 - 40 - 50, width: 50, height: 50)
    emptySequenceButton.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplayBack.addSubview(emptySequenceButton)
    
    let testLevelButton = NSButton(title: "Test Level", image: #imageLiteral(resourceName: "playIcon.png"), target: vc, action: #selector(vc.testCreatedLevel))
    testLevelButton.imagePosition = .noImage
    testLevelButton.isBordered = true
    testLevelButton.frame = NSRect(x: 150 - 50, y:  15, width: 100, height: 50)
    testLevelButton.layerContentsRedrawPolicy = .onSetNeedsDisplay
    levelDisplayBack.addSubview(testLevelButton)
    
    return levelDisplayBack
    
}



public func setMessage(message: String, duration: Int){
        introLabel.stringValue = message
    viewIN(width: message.width(height: 50, font: introLabel.font!))
  
    
    if duration != 0 {
        let delay = Double(duration)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delay) {
            if !isResetting {
               // viewOut()

            }
        }
        
    }
}

public func viewIN(width: CGFloat){
    introLabel.setFrameSize(CGSize(width: width + 100, height: introLabel.frame.height))
    introLabel.alignment = .center
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        visualEffectsView.animator().frame = NSRect(x: WIDTH/2 - Int(width/2) - 50, y: 75, width: Int(width) + 100, height: 50)
        visualEffectsView.animator().alphaValue = 1
    }) {
       
    }
    
}



public func viewOut(){
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        visualEffectsView.animator().frame = NSRect(x: WIDTH/2 - 150, y: -50, width: 300, height: 50)
        visualEffectsView.animator().alphaValue = 0
    }) {
        
    }
}

public func slideLevelDisplayRight(viewController: PlaygroundViewController) {
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        rightLevelDisplay.animator().frame = currentLevelDisplay.frame
        rightLevelDisplay.animator().alphaValue = 1
    }) {
        
    }
    
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        currentLevelDisplay.animator().frame = NSRect(x: 50, y: currentLevelDisplay.frame.minY, width: 150, height: 300)
        currentLevelDisplay.animator().alphaValue = 0
    }) {
        levelIndexCurrent += 1
        //currentLevelDisplay.removeFromSuperview()
        holderView = rightLevelDisplay
        rightLevelDisplay = currentLevelDisplay
        currentLevelDisplay = holderView
        rightLevelDisplay.removeFromSuperview()
        if levelIndexCurrent <= levelsOnScreen.count - 2{

        rightLevelDisplay = createLevelDisplay(frame: NSRect(x: WIDTH - 50 - 150, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: viewController, level: levelsOnScreen[levelIndexCurrent + 1])
        }else{
             rightLevelDisplay = createLevelDisplayAction(frame: NSRect(x: WIDTH - 50 - 150, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: viewController)
        }
        rightLevelDisplay.alphaValue = 0
        levelDisplay.addSubview(rightLevelDisplay)
        
        leftLevelDisplay.removeFromSuperview()
        
        if levelIndexCurrent > 0{
        leftLevelDisplay = createLevelDisplay(frame: NSRect(x: 50, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: viewController,  level: levelsOnScreen[levelIndexCurrent - 1])
        }
        leftLevelDisplay.alphaValue = 0
        levelDisplay.addSubview(leftLevelDisplay)
        isAnimating = false
    }
}

public func slideLevelDisplayLeft(viewController: PlaygroundViewController) {
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        leftLevelDisplay.animator().frame = currentLevelDisplay.frame
        leftLevelDisplay.animator().alphaValue = 1
    }) {
        
    }
    
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        currentLevelDisplay.animator().frame = NSRect(x: WIDTH - 150 - 50, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300)
        currentLevelDisplay.animator().alphaValue = 0
    }) {
        levelIndexCurrent -= 1
        //currentLevelDisplay.removeFromSuperview()
        holderView = leftLevelDisplay
        leftLevelDisplay = currentLevelDisplay
        currentLevelDisplay = holderView
        leftLevelDisplay.removeFromSuperview()
        if levelIndexCurrent > 0{

        leftLevelDisplay = createLevelDisplay(frame: NSRect(x: 50, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: viewController,  level: levelsOnScreen[levelIndexCurrent - 1])
        }
        
        rightLevelDisplay.removeFromSuperview()
        if levelIndexCurrent <= levelsOnScreen.count - 2{
            
            rightLevelDisplay = createLevelDisplay(frame: NSRect(x: WIDTH - 50 - 150, y: Int(currentLevelDisplay.frame.minY), width: 150, height: 300), vc: viewController, level: levelsOnScreen[levelIndexCurrent + 1])
        }
        rightLevelDisplay.alphaValue = 0
        levelDisplay.addSubview(rightLevelDisplay)
        
        leftLevelDisplay.alphaValue = 0
        levelDisplay.addSubview(leftLevelDisplay)
        isAnimating = false
    }
}

public func showLevelView(){
    isOnLevelMenu = true
    scene.filter?.setValue(15, forKey: kCIInputRadiusKey)
    levelDisplay.frame = NSRect(x: 0, y: 0, width: WIDTH, height: HEIGHT)


    hideDisplayMenu()
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        levelDisplay.animator().alphaValue = 1
    }) {
    }
    viewOut()
}

public func hideLevelViewToStart(){
    isOnLevelMenu = false
    showDisplayMenu()
    scene.filter?.setValue(0, forKey: kCIInputRadiusKey)

    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        levelDisplay.animator().alphaValue = 0
    }) {
        levelDisplay.frame = NSRect(x: 0, y: HEIGHT, width: WIDTH, height: HEIGHT)

    }
}

public func hideDisplayMenu() {
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        menuStartDisplay.animator().alphaValue = 0
    }) {
        menuStartDisplay.frame = NSRect(x: WIDTH/2 - 150, y: 75, width: 300, height: -75)
    }
}

public func showDisplayMenu() {
    
    menuStartDisplay.frame = NSRect(x: WIDTH/2 - 150, y: 75, width: 300, height: 50)
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        menuStartDisplay.animator().alphaValue = 1
    }) {
        
    }
}

public func showWinScreen(score: Int, health: Int){
    
    healthLabel.stringValue = "Final Health: \(health)"
    scoreLabel.stringValue = "Score: \(score)"
    
    winScreen.frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        winScreen.animator().frame = NSRect(x: 0, y: 0, width: WIDTH, height: HEIGHT)
        winScreen.animator().alphaValue = 1
    }) {
    }
}

public func hideWinScreen(){
    
    onWinScreen = false
    onLossScreen = false
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        winScreen.animator().frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)
        winScreen.animator().alphaValue = 0
    }) {
        winScreen.frame = NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT)
    }
}

public func playLevel(){
    scene.playLevel(level: levelsOnScreen[levelIndexCurrent])
    currentLevel = levelIndexCurrent
}

public func nextLevelButtonAction(){
    winScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.2)) {
        hideWinScreen()
        
        if levelsOnScreen[currentLevel + 1] != nil{
            scene.loadLevel(level: levelsOnScreen[currentLevel + 1])
            currentLevel += 1
            scene.updateCircleLightsSize(size: 12)
        }
    }
}

public func showLossScreen(score: Int, health: Int){
    
    scene.currentMessage = ""
    viewOut()
    
    healthLossLabel.stringValue = "Final Health: \(health)"
    scoreLossLabel.stringValue = "Score: \(score)"
    
    lossScreen.frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        lossScreen.animator().frame = NSRect(x: 0, y: 0, width: WIDTH, height: HEIGHT)
        lossScreen.animator().alphaValue = 1
    }) {
    }
}

public func hideLossScreen(){
    onWinScreen = false
    onLossScreen = false
    viewOut()
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        lossScreen.animator().frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)
        lossScreen.animator().alphaValue = 0
    }) {
        lossScreen.frame = NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT)
    }
}

public func replayLevelButtonAction(){
    

    for pellet in pellets{
        pellet.value.removeFromParent()
    }
    pellets.removeAll()
    
    for pellet in pelletTutorial1{
        pellet.value.removeFromParent()
    }
    
    pelletTutorial1.removeAll()
    
    for pellet in pelletTutorial2{
        pellet.value.removeFromParent()
    }
    
    pelletTutorial2.removeAll()
    
    onLossScreen = false
    onWinScreen = false
    isResetting = false
    
    HEALTH = 100
    SCORE = 0
    
    lossScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.2)) {
        hideLossScreen()
        
        if levelsOnScreen[currentLevel] != nil{
            scene.loadLevel(level: levelsOnScreen[currentLevel])
            currentLevel += 0
            scene.updateCircleLightsSize(size: 12)
        }
    }
}

public func toMainScreenButtonAction(){
    hideWinScreen()
    hideLossScreen()
    viewOut()
    onWinScreen = false
    onLossScreen = false
    winScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.2))
    lossScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.2))

    scene.resetScene()
}

public func toSequenceEditor(){
    hideLevelViewToStart()
    hideDisplayMenu()
    scene.playLevel(level: Level())
    setMessage(message: "Click to add pellets", duration: 0)
    isEditing = true
    scene.currentMessage = "Click to add pellets"
   
    editorHud.frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)

    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        editorHud.animator().alphaValue = 1
        editorHud.frame = NSRect(x: 0, y: 0, width: WIDTH, height: HEIGHT)

    }) {
    }
    
    let moveUpAction = SKAction.move(by: CGVector(dx: 0, dy: 60), duration: 0.3)
    
    scene.editingToolbar.run(moveUpAction)
    scene.blueEdit.run(moveUpAction)
    scene.redEdit.run(moveUpAction)
    scene.yellowEdit.run(moveUpAction)
    scene.greenEdit.run(moveUpAction)
    
}

public func hideEditor(){
    scene.resetScene()
    isEditing = false
    scene.isPaused = false
    
    NSAnimationContext.runAnimationGroup({ (context) in
        context.duration = 0.3
        editorHud.animator().frame = NSRect(x: 0, y: -50, width: WIDTH, height: HEIGHT)
        editorHud.animator().alphaValue = 0
    }) {
        editorHud.frame = NSRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT)
    }
    
    var moveDownAction = SKAction.move(by: CGVector(dx: 0, dy: -60), duration: 0.3)
    
    scene.editingToolbar.run(moveDownAction)
    scene.blueEdit.run(moveDownAction)
    scene.redEdit.run(moveDownAction)
    scene.yellowEdit.run(moveDownAction)
    scene.greenEdit.run(moveDownAction)
    viewOut()
    
    
}

