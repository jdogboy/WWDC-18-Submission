import Foundation
import SpriteKit
import Darwin

//Global Vars (Necessary)
let WIDTH = 640
let HEIGHT = 480

public var currentLevel = 0

public var mainColor: CIColor = CIColor(red: 0.0, green: 0.0, blue: 0.0)

//GLobal Vars (Not Necessary)
var filter: CIFilter?
var startDrag: CGPoint?
var mousePos: CGPoint? = CGPoint.zero
let circleNode = Pellet(radius: 0, position: CGPoint.zero)

//Global Flag for messages
public var isResetting = false
public var onWinScreen = false
public var onLossScreen = false
public var isEditing = false


//Game Variables
public var HEALTH = 100
public var SCORE = 0

//Pellet Array (Contains all pellets)
public var pellets: [Int:SKShapeNode] = [:]
var pelletIndex = 0

//Ring Array (For Yellow Pellets)
public var yellowRings: [SKShapeNode] = []

var pelletTutorial1: [String:SKShapeNode] = [:]
var pelletTutorial2: [String:SKShapeNode] = [:]

//Health and Score
public var healthBar = SKShapeNode(rect: CGRect(x: 25, y: 10, width: WIDTH/3, height: 15), cornerRadius: 5)
public var scoreBar = SKShapeNode(rect: CGRect(x: WIDTH/3 + 50, y: 10, width: WIDTH/3, height: 15), cornerRadius: 5)


//Mouse Loc
var mousePosLocal = CGPoint.zero
var prevMousePosGlobal = CGPoint.zero
var prevMousePosLocal = CGPoint.zero
var isMovingLocal = false
var isMovingGlobal = false
var isOffScreen = true
var mouseDown = false
public var isOnLevelMenu = false
var clampedGLSLMousePos = vector2(Float(1.0), Float(1.0))


//Levels
var levelsOnScreen: [Level] = []

//Global Uniform Variables
var circleSize: Float = 12.0

//Boss
var bossNode: Pellet!
var bossHealth = 1000
var bossStrength = 20
var bossAttacking = false

var hpLabel: SKLabelNode!

var healthlabelOnScreen: SKLabelNode!

var shaders: [SKShader] = []

var winScreenBack = SKShapeNode(rect: CGRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT))
var lossScreenBack = SKShapeNode(rect: CGRect(x: 0, y: -HEIGHT, width: WIDTH, height: HEIGHT))


//Toolbar

var currentSequencePellets: [Pellet] = []

public class Scene: SKScene, SKPhysicsContactDelegate {
    
    //Editing Tool Bar
    var editingToolbar = SKShapeNode(rect: CGRect(x: 0, y: -60, width: WIDTH, height: 60))
    var redEdit: Pellet!
    var blueEdit: Pellet!
    var greenEdit: Pellet!
    var yellowEdit: Pellet!
    var selectedPellet = 0

    
    
    //Shaders
    let blobShader = SKShader(fileNamed: "blob.fsh")
    let coloredLights = SKShader(fileNamed: "coloredLights.fsh")
    let ringShader = SKShader(fileNamed: "colorBlob2.fsh")
    let colorColumns = SKShader(fileNamed: "colorColumns.fsh")
    let bubble = SKShader(fileNamed: "bubble.fsh")
    let colorBlob = SKShader(fileNamed: "colorBlob.fsh")
    let colorSwirl = SKShader(fileNamed: "coloredRing.fsh")
    let radial = SKShader(fileNamed: "radial.fsh")
    
    
    //Public Entities
     public var colorBack = SKShapeNode(rect: CGRect(x: 0, y: 0, width: WIDTH, height: HEIGHT), cornerRadius: 3)
    let circleBack = Pellet(radius: 0, position: CGPoint.zero)
    
    let middleShader = Pellet(radius: 0, position: CGPoint.zero)
    
    let mousePhysicsNode = SKSpriteNode(imageNamed: "cursor.png")
    
    //Flags
    var onStartScreen = true
    var isBruised = false
    var isHolding = true
    var isClassPaused = false
    var intentionalSlomo = false
    var isBursting = false
    var bluePelletExists = true
    var bossHolesAdded = false
    var onBossScreen = false
    
    var holesNotChecked = 0
    
    
    //Timer
    var canShoot = true
    var secondsOfBurst = 0
    
    //Bitmasks
    var mouseBitmask: UInt32 = 0x1 << 0
    var redPelletBitmask: UInt32 = 0x1 << 1
    var bluePelletBitmask: UInt32 = 0x1 << 2
    var greenPelletBitmask: UInt32 = 0x1 << 3
    var mouseBullet: UInt32 = 0x1 << 4
    
    var yellowPelletBitmask: UInt32 = 0x1 << 5
    var yellowPelletHole: UInt32 = 0x1 << 6
    var purplePelletBitmask: UInt32 = 0x1 << 7
    var bossBitmask: UInt32 = 0x1 << 8

    
    //Pause Screen
    var pauseScreen = SKShapeNode(rect: CGRect(x: -15, y: -15 - HEIGHT - 16, width: WIDTH + 30, height: HEIGHT + 30))
    var pausedIcon = SKSpriteNode(imageNamed: "pauseIcon")
    var blurPause = SKEffectNode()
    var blurPauseEffect: CIFilter!
    
    var currentMessage = ""
    
    //Win Screen
    var blurWin = SKEffectNode()
    var blurWinEffect: CIFilter!

    
    //Lose Screen
    var loseScreen = SKShapeNode(rect: CGRect(x: -15, y: -15, width: WIDTH, height: HEIGHT))
    var blurLose = SKEffectNode()
    var blurLoseEffect: CIFilter!

    
    
    //Backgrounds
    var currentBackground: SKShader!
    
    //Logic
    var currentActionsInSequence: [SKAction] = []

    //Arrows
    var arrowDirection = CGVector(dx: 0, dy: 10000)
    
    //Action Maker (Basically anything that is a fake action [I could use Grand Central Dispatch, but I really don't want to])
    var actionNode = SKNode()
    
    
    //Level Progression
    var quickCut: () -> Void = {}
    var lengthenTimeCheck: () -> Void = {}
    var needsLengthening = false
    var neededLengthening = false
    
   public override  init(size: CGSize) {
        super.init(size: size)
    
    physicsWorld.contactDelegate = self

    
        colorBack.strokeColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        addChild(colorBack)
    
    let blurNode = SKEffectNode()
    filter  = CIFilter(name: "CIGaussianBlur")
    filter?.setValue(0, forKey: kCIInputRadiusKey)
    blurNode.filter = filter
    blurNode.blendMode = .screen
    addChild(blurNode)
    
        
        
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        let backgroundNode = SKShapeNode(rect:CGRect(x: 0, y: 0, width: WIDTH, height: HEIGHT), cornerRadius: 3)
        backgroundNode.fillColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
        backgroundNode.strokeColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        backgroundNode.fillShader = blobShader
        
        
        
        let backgroundSize = vector2(Float(backgroundNode.frame.width), Float(backgroundNode.frame.height))
    
    
    shaders.append(blobShader)
    shaders.append(coloredLights)
    shaders.append(ringShader)
    shaders.append(colorColumns)
    shaders.append(bubble)
    shaders.append(colorBlob)
    shaders.append(colorSwirl)
    shaders.append(radial)
    
    for shader in shaders{
        shader.uniforms = [
            SKUniform(name: "resolution", vectorFloat2: backgroundSize),
            SKUniform(name: "positionMouse", vectorFloat2: clampedGLSLMousePos),
            SKUniform(name: "touchbarColor", vectorFloat3: vector3(1.0, 1.0, 1.0)),
            SKUniform(name: "circleSize", float: Float(circleSize)),
            SKUniform(name: "speedGlobal", float: Float(shaderSpeed))
        ]
    }
    
    
    blurNode.addChild(backgroundNode)
    
    circleNode.fillShader = coloredLights
    
    circleBack.fillColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    circleBack.strokeColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
   // middleShader.fillColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    //middleShader.fillShader = ringShader
    addChild(circleBack)
    addChild(middleShader)
    
    addChild(circleNode)
    
    mousePhysicsNode.position = CGPoint.zero
    mousePhysicsNode.size = CGSize(width: 17, height: 25)
    mousePhysicsNode.alpha = 0
    mousePhysicsNode.physicsBody = SKPhysicsBody(texture:SKTexture(imageNamed: "cursor.png"), size: CGSize(width: 17, height: 25))
    mousePhysicsNode.physicsBody?.affectedByGravity = false
    mousePhysicsNode.physicsBody?.allowsRotation = false
    mousePhysicsNode.physicsBody?.isDynamic = false
    mousePhysicsNode.physicsBody?.usesPreciseCollisionDetection = true
    mousePhysicsNode.physicsBody?.categoryBitMask = mouseBitmask
    mousePhysicsNode.physicsBody?.usesPreciseCollisionDetection = true
    mousePhysicsNode.physicsBody?.contactTestBitMask = redPelletBitmask | bluePelletBitmask | greenPelletBitmask
    addChild(mousePhysicsNode)
    
    
    //Health And Score Bar
    healthBar.strokeShader = coloredLights
    healthBar.lineWidth = 7
    healthBar.fillColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
    healthBar.xScale = 0
    
    scoreBar.strokeShader = coloredLights
    scoreBar.lineWidth = 7
    scoreBar.fillColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
    scoreBar.xScale = 0
    
    addChild(healthBar)
    
    
    healthlabelOnScreen = SKLabelNode(text: "Health: \(HEALTH)")
    healthlabelOnScreen.fontName = "Avenir"
    healthlabelOnScreen.fontSize = 17
    healthlabelOnScreen.position = CGPoint(x: 70, y: 30)
    healthlabelOnScreen.alpha = 0
    addChild(healthlabelOnScreen)
    
    addChild(scoreBar)
    
    //Boss
     bossNode = Pellet(radius: 100, position: CGPoint(x: WIDTH/2, y: HEIGHT + 110))
    bossNode.fillShader = blobShader
    bossNode.lineWidth = 17
    bossNode.strokeShader = coloredLights
    bossNode.physicsBody = SKPhysicsBody(circleOfRadius: 100)
    bossNode.physicsBody?.usesPreciseCollisionDetection = true
    bossNode.physicsBody?.isDynamic = false
    bossNode.physicsBody?.categoryBitMask = bossBitmask
    bossNode.name = "bossNode"
    addChild(bossNode)
    
    hpLabel = SKLabelNode(text: "HP: \(bossHealth)")
    hpLabel.fontName = "Avenir"
    hpLabel.fontSize = 17
    hpLabel.position = CGPoint(x: 0, y: 130)
    bossNode.addChild(hpLabel)
    
    //Editing Toolbar
    editingToolbar.fillColor = #colorLiteral(red: 0.2027820945, green: 0.220297873, blue: 0.2437761426, alpha: 1)
    editingToolbar.lineWidth = 0
    addChild(editingToolbar)
    redEdit = addRedPellet(position: CGPoint(x: WIDTH/2 - 60, y: 30 - 60))
    redEdit.physicsBody?.isDynamic = false
    redEdit.name = "redEdit"

    
    greenEdit = addGreenPellet(position: CGPoint(x: WIDTH/2 - 25, y: 30 - 60))
    greenEdit.physicsBody?.isDynamic = false
    greenEdit.name = "greenEdit"

    
    blueEdit = addBluePellet(position: CGPoint(x: WIDTH/2 + 14, y: 30 - 60))
    blueEdit.physicsBody?.isDynamic = false
    blueEdit.name = "blueEdit"
    
    yellowEdit = addYellowPelletWithoutHole(position: CGPoint(x: WIDTH/2 + 50, y: 30 - 60))
    yellowEdit.physicsBody?.isDynamic = false
    yellowEdit.name = "yellowEdit"
    
    
    
    
    
    
    //Pause Screen
    blurPauseEffect = CIFilter(name: "CIGaussianBlur")
    blurPauseEffect.setValue(0, forKey: kCIInputRadiusKey)
    blurPause.filter = blurPauseEffect
    addChild(blurPause)
    
    pauseScreen.fillShader = colorColumns
    blurPause.addChild(pauseScreen)
   
    pausedIcon.position = CGPoint(x: (WIDTH/2), y: (HEIGHT/2) - 50)
    pausedIcon.alpha = 0
    addChild(pausedIcon)
    
    
    // Win Screen
    blurWinEffect = CIFilter(name: "CIGaussianBlur")
    blurWinEffect.setValue(0, forKey: kCIInputRadiusKey)
    blurWin.filter = blurWinEffect
    addChild(blurWin)
    winScreenBack.fillShader = ringShader
    lossScreenBack.fillShader = bubble
    blurWin.addChild(lossScreenBack)
    addChild(winScreenBack)

    
    
    addChild(actionNode)
    
    levelsOnScreen.append(createTutorialLevel())
    levelsOnScreen.append(createLevel1())
    levelsOnScreen.append(createLevel2())
    levelsOnScreen.append(createFinalBoss())
    
   // currentBackground = coloredLights
    
    
    

        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func update(_ currentTime: TimeInterval) {
        
       // print(currentLevel)
        
      //  print(currentBackground)
        
        //print(clampedGLSLMousePos)
        

        if(bossAttacking) && self.nodes(at: mousePosLocal)[0].name == "bossNode"{
            if !isBruised{
               damageHealth(damageTaken: 10)
                startBruising()
            }
        }
        

        
        if bossHealth >= 0 {
            hpLabel.text = "HP: \(bossHealth)"
        }
        
        healthlabelOnScreen.text = "Health: \(HEALTH)"
        
       // middleShader.fillShader = currentBackground
        
        
        
        bluePelletExists = checkExistingBluePellets()
        
        //Quick Cuts must ALWAYS be if checks. Anthing else gets called all the time
        
        // Guidelines for Quick Cuts
        // 1. Must be an if statement
        // 2. Must also clear itself after it runs (needs to runs only once)
        // 3. Make sure it also advances actions as well. Awkward pauses are NOT acceptable!
        
        if !isResetting {
            quickCut()
            lengthenTimeCheck()
        }
        
        if !isEditing{
            for pellet in pellets {
                
                let pelletNode = pellet.value as! Pellet
                
                if pelletNode.stringID == "noPull" {
                    continue
                }
                
                let mass1 = (pellet.value.physicsBody?.mass)! + 10000
                let mass2 = (mousePhysicsNode.physicsBody?.mass)! * 40000
                let directionToMouse = CGVector(dx: mousePosLocal.x - pellet.value.position.x, dy:  mousePosLocal.y - pellet.value.position.y)
                let radius = sqrt(directionToMouse.dx*directionToMouse.dx + directionToMouse.dy*directionToMouse.dy)
                if radius < 25.0 {
                    continue
                }
                let force = (mass1 * mass2) / (radius * radius)
                let normal = CGVector(dx: directionToMouse.dx / radius, dy: directionToMouse.dy / radius)
                let impulse = CGVector(dx: normal.dx * force * (1.0/60.0), dy: normal.dy * force * 1.0/60.0)
                pellet.value.physicsBody?.velocity = CGVector(dx: (pellet.value.physicsBody?.velocity.dx)! + impulse.dx, dy: (pellet.value.physicsBody?.velocity.dy)! + impulse.dy)
                
            }
        }
       
        
        if HEALTH <= 0 && onStartScreen == false && !isResetting{
            bossAttacking = false
            updateCircleLightsSize(size: 12)
            loseScreenAct()
            
            
            healthlabelOnScreen.alpha = 0
        }
        
        let vc = VC as! PlaygroundViewController
        let globalMousePos = vc.getLocation()
        
        if globalMousePos != prevMousePosGlobal {
            isMovingGlobal = true
        }else{
            isMovingGlobal = false
            isMovingLocal = false
        }
        
        prevMousePosGlobal = globalMousePos
        
        
        if mousePosLocal != prevMousePosLocal {
            isMovingLocal = true
        }else{
            isMovingLocal = false
        }
        
        prevMousePosLocal = mousePosLocal
        
        if !onStartScreen{
            if !isClassPaused && !onWinScreen && !onLossScreen && !isEditing{
                if(!isMovingLocal && isMovingGlobal){
                    isOffScreen = true
                    isClassPaused = true
                    
                    pauseScene()
                }
            }
            
            if isClassPaused{
                
                if (isMovingLocal) {
                    isOffScreen = false
                    isClassPaused = false
                    unpauseScene()
                }
            }
        }
        
        if !isResetting && !onStartScreen && isHolding && !onWinScreen && !onLossScreen && canShoot && !isEditing{
            explode(position: mousePosLocal)
            if isBursting{
                shootBurst(position: mousePosLocal)
                //This will give problems!!!
                actionNode.run(SKAction.wait(forDuration: 5), completion: {
                    if !self.onBossScreen {
                        self.updateCircleLightsSize(size: 12)
                        circleSize = 12.0
                    }
                    self.isBursting = false
                })
            }else{
                shootSingle(position: mousePosLocal)

            }
            canShoot = false
            //Delay between shooting periods (Saves lag)
            self.run(SKAction.wait(forDuration: 0.1), completion: {
                self.canShoot = true
            })
        }
        
    }
    
    
    public override func mouseDown(with event: NSEvent) {
        
        
        if isEditing{
            if let name = self.nodes(at: event.location(in: self))[0].name {
                if name == "redEdit"{
                    selectedPellet = 0
                }else if name == "blueEdit"{
                    selectedPellet = 1
                }else if name == "greenEdit"{
                    selectedPellet = 2
                }else if name == "yellowEdit"{
                    selectedPellet = 3
                }
                
                
                return
            }
            
            switch selectedPellet{
            case 0:
                let pellet = addRedPellet(position: event.location(in: self))
                currentSequencePellets.append(pellet)
                pellet.physicsBody?.isDynamic = false
                pellet.position = event.location(in: self)
            case 1:
                
                let pellet = addBluePellet(position: event.location(in: self))
                currentSequencePellets.append(pellet)

                pellet.physicsBody?.isDynamic = false

            case 2:
                let pellet = addGreenPellet(position: event.location(in: self))
                currentSequencePellets.append(pellet)

                pellet.physicsBody?.isDynamic = false


            case 3:
                let pellet = addRedPellet(position: event.location(in: self))
                currentSequencePellets.append(pellet)

                pellet.physicsBody?.isDynamic = false
                pellet.position = event.location(in: self)
            default:
                return
            }
        }

        //Initiates drag on start screen
        if onStartScreen && !isResetting && !isOnLevelMenu && !isEditing{
           // print(levelsOnScreen[currentLevel].sequences[0].background?.shaderBack)
        self.middleShader.fillShader = levelsOnScreen[currentLevel].sequences[0].background?.shaderBack
        startDrag = event.location(in: self)
        circleNode.position = startDrag!
        circleNode.radius = 0
        circleBack.radius = 0
        middleShader.radius = 0
        middleShader.position = startDrag!
        circleBack.position = startDrag!
            
        }
        
        isHolding = true
        mousePosLocal = event.location(in: self)
    }
    
    public override func mouseMoved(with event: NSEvent) {
        
        
        //Updates Mouse Pos on shaders, more to come
        let actualLocation = event.location(in: self)
        let clampedLocation = CGPoint(x: (actualLocation.x / CGFloat(WIDTH/2)) - 1, y: (actualLocation.y / CGFloat(HEIGHT/2)) - 1)
        let mousePosition = vector2(Float(-1 * clampedLocation.x * 1.3), Float(clampedLocation.y))
        clampedGLSLMousePos = mousePosition
        let backgroundSize = vector2(Float(WIDTH), Float(HEIGHT))
        mousePos = clampedLocation
        
        for shader in shaders{
            shader.uniforms = [
                SKUniform(name: "resolution", vectorFloat2: backgroundSize),
                SKUniform(name: "positionMouse", vectorFloat2: mousePosition),
                SKUniform(name: "touchbarColor", vectorFloat3: vector3(Float(mainColor.red), Float(mainColor.red), Float(mainColor.blue))),
                SKUniform(name: "circleSize", float: Float(circleSize)),
                SKUniform(name: "speedGlobal", float: Float(shaderSpeed))
                
            ]
        }
        
        
        //Spritekit Implementation
        mousePhysicsNode.position = CGPoint(x: actualLocation.x + 5, y: actualLocation.y - 6)
        
        
        //Mouse
        mousePosLocal = actualLocation
        
      
    }
    
   public override func mouseDragged(with event: NSEvent) {
    
    middleShader.removeAllActions()
    
    let actualLocation = event.location(in: self)
    let clampedLocation = CGPoint(x: (actualLocation.x / CGFloat(WIDTH/2)) - 1, y: (actualLocation.y / CGFloat(HEIGHT/2)) - 1)
    let mousePosition = vector2(Float(-1 * clampedLocation.x * 1.3), Float(clampedLocation.y))
    clampedGLSLMousePos = mousePosition
    let backgroundSize = vector2(Float(WIDTH), Float(HEIGHT))
    mousePos = clampedLocation
    
    for shader in shaders{
        shader.uniforms = [
            SKUniform(name: "resolution", vectorFloat2: backgroundSize),
            SKUniform(name: "positionMouse", vectorFloat2: clampedGLSLMousePos),
            SKUniform(name: "touchbarColor", vectorFloat3: vector3(Float(mainColor.red), Float(mainColor.red), Float(mainColor.blue))),
            SKUniform(name: "circleSize", float: Float(circleSize)),
            SKUniform(name: "speedGlobal", float: Float(shaderSpeed))
            
        ]
        
    }
    
    
    if onStartScreen && !isResetting && !isOnLevelMenu{
    
        
        middleShader.alpha = 1

        
        let current = event.location(in: self)
        var xSquare = (current.x - (startDrag?.x)!)
        xSquare = xSquare * xSquare
        var ySquare = (current.y - (startDrag?.y)!)
        ySquare = ySquare * ySquare
        let distance = sqrt(ySquare + xSquare)
        filter?.setValue(distance/20, forKey: kCIInputRadiusKey)
        circleNode.radius = Double(distance)
        circleBack.radius = Double(distance)
        middleShader.radius = Double(distance)
    
    }
    
    mousePosLocal = actualLocation
    mousePhysicsNode.position = CGPoint(x: actualLocation.x + 5, y: actualLocation.y - 6)
    

    
    }
    
   public override func mouseUp(with event: NSEvent) {
        playLevel(level: levelsOnScreen[currentLevel])
    
    isHolding = false
    mousePosLocal = event.location(in: self)
    
    }
    
    public override func keyDown(with event: NSEvent) {
        
        
        
        switch event.keyCode {
        case 13:
                arrowDirection = CGVector(dx: 0, dy: 10000)
        case 0:
            arrowDirection = CGVector(dx: -10000, dy: 0)

        case 1:
            arrowDirection = CGVector(dx: 0, dy: -10000)
        case 2:
            arrowDirection = CGVector(dx:   10000, dy: 0)


        case 123:
            arrowDirection = CGVector(dx: -10000, dy: 0)

        case 124:
            arrowDirection = CGVector(dx: 10000, dy: 0)
        case 125:
            arrowDirection = CGVector(dx: 0, dy: -10000)
        case 126:
            arrowDirection = CGVector(dx: 0, dy: 10000)
        default:
            return
        }
    }
    
    
    public override func keyUp(with event: NSEvent) {
        //arrowDirection = CGVector(dx: 0, dy: 10000)
    }
    
    func addRedPellet(position: CGPoint) -> Pellet{
        let redPellet = Pellet(radius: 5, position: CGPoint.zero)
        redPellet.fillColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
        //redPellet.fillShader = blobShader
        redPellet.strokeShader = coloredLights
       redPellet.lineWidth = 10
        redPellet.position = position
        redPellet.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        redPellet.physicsBody?.usesPreciseCollisionDetection = true
        redPellet.physicsBody?.categoryBitMask = redPelletBitmask
        redPellet.index = pelletIndex
        pelletIndex += 1
        
        addChild(redPellet)
        //redPellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        return redPellet
        
    }
    
    func addBluePellet(position: CGPoint) -> Pellet{
        let bluePellet = Pellet(radius: 10, position: CGPoint.zero)
        bluePellet.fillColor = #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)
        //redPellet.fillShader = blobShader
        bluePellet.strokeShader = coloredLights
        bluePellet.lineWidth = 10
        bluePellet.position = position
        bluePellet.physicsBody = SKPhysicsBody(circleOfRadius: 20)
        bluePellet.physicsBody?.usesPreciseCollisionDetection = true
        bluePellet.physicsBody?.categoryBitMask = bluePelletBitmask
        bluePellet.index = pelletIndex
        bluePellet.stringID = "BLUEPELLET"
        pelletIndex += 1
        addChild(bluePellet)
        //redPellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        return bluePellet
        
    }
    
    
    func addGreenPellet(position: CGPoint) -> Pellet{
        let greenPellet = Pellet(radius: 5, position: CGPoint.zero)
        greenPellet.fillColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        //redPellet.fillShader = blobShader
        greenPellet.strokeShader = coloredLights
        greenPellet.lineWidth = 10
        greenPellet.position = position
        greenPellet.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        greenPellet.physicsBody?.usesPreciseCollisionDetection = true
        greenPellet.physicsBody?.categoryBitMask = greenPelletBitmask
        greenPellet.index = pelletIndex
        pelletIndex += 1
        addChild(greenPellet)
        greenPellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        return greenPellet
        
    }
    
    func addPurplePellet(position: CGPoint) -> Pellet{
        let purplePellet = Pellet(radius: 5, position: CGPoint.zero)
        purplePellet.fillColor = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
        //redPellet.fillShader = blobShader
        purplePellet.strokeShader = coloredLights
        purplePellet.lineWidth = 10
        purplePellet.position = position
        purplePellet.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        purplePellet.physicsBody?.usesPreciseCollisionDetection = true
        purplePellet.physicsBody?.categoryBitMask = purplePelletBitmask
        purplePellet.index = pelletIndex
        pelletIndex += 1
        addChild(purplePellet)
        purplePellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        return purplePellet
    }
    
    
    func addYellowPellet(position: CGPoint, holePosition: CGPoint) -> Pellet{
        let yellowPellet = Pellet(radius: 7, position: CGPoint.zero)
        yellowPellet.fillColor = #colorLiteral(red: 1, green: 0.9060394764, blue: 0, alpha: 1)
        yellowPellet.strokeShader = coloredLights
        yellowPellet.lineWidth = 10
        yellowPellet.position = position
        yellowPellet.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        yellowPellet.physicsBody?.usesPreciseCollisionDetection = true
        yellowPellet.physicsBody?.categoryBitMask = yellowPelletBitmask
        yellowPellet.physicsBody?.contactTestBitMask = yellowPelletHole
        yellowPellet.index = pelletIndex
        pelletIndex += 1
        addChild(yellowPellet)
        yellowPellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        
        let yellowHole = Pellet(radius: 15, position: holePosition)
        yellowHole.fillColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
        yellowHole.lineWidth = 5
        yellowHole.position = holePosition
        yellowHole.physicsBody = SKPhysicsBody(circleOfRadius: 7)
        yellowHole.physicsBody?.usesPreciseCollisionDetection = true
        yellowHole.physicsBody?.isDynamic = false
        yellowHole.physicsBody?.categoryBitMask = yellowPelletHole
        yellowHole.physicsBody?.contactTestBitMask = yellowPelletBitmask
        yellowHole.stringID = "noPull"
        pellets[pelletIndex] = yellowHole
        pelletIndex += 1
        yellowRings.append(yellowHole)
        holesNotChecked += 1
        addChild(yellowHole)
        
        return yellowPellet
        
    }
    
    func addYellowPelletWithoutHole(position: CGPoint) -> Pellet{
        let yellowPellet = Pellet(radius: 7, position: CGPoint.zero)
        yellowPellet.fillColor = #colorLiteral(red: 1, green: 0.9060394764, blue: 0, alpha: 1)
        yellowPellet.strokeShader = coloredLights
        yellowPellet.lineWidth = 10
        yellowPellet.position = position
        yellowPellet.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        yellowPellet.physicsBody?.usesPreciseCollisionDetection = true
        yellowPellet.physicsBody?.categoryBitMask = yellowPelletBitmask
        yellowPellet.physicsBody?.contactTestBitMask = yellowPelletHole
        yellowPellet.index = pelletIndex
        pelletIndex += 1
        addChild(yellowPellet)
        yellowPellet.physicsBody?.applyForce(CGVector(dx: Int(arc4random_uniform(500)) - 250, dy: Int(arc4random_uniform(500)) - 250 ))
        return yellowPellet
        
    }
    
    
    
    func shootSingle(position: CGPoint) {
        let arrowNode = SKSpriteNode(imageNamed: "cursor.png")
        arrowNode.size = CGSize(width: 17, height: 25)
        if arrowDirection.dy > 0 {
            arrowNode.position = CGPoint(x: position.x, y: position.y + 30)

        }else if arrowDirection.dy < 0 {
            arrowNode.position = CGPoint(x: position.x, y: position.y - 30)
        }
        
        if arrowDirection.dx > 0 {
            arrowNode.position = CGPoint(x: position.x + 30, y: position.y )
            
        }else if arrowDirection.dx < 0{
            arrowNode.position = CGPoint(x: position.x - 30, y: position.y)
        }
        
        arrowNode.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: "cursor.png"), size: CGSize(width: 17, height: 25))
        arrowNode.physicsBody?.mass = 0
        arrowNode.physicsBody?.friction = 0
        arrowNode.physicsBody?.categoryBitMask = mouseBullet
        arrowNode.physicsBody?.contactTestBitMask = redPelletBitmask | bossBitmask
        addChild(arrowNode)
        arrowNode.physicsBody?.applyForce(arrowDirection)
        
        
        
        
        arrowNode.run(SKAction.fadeOut(withDuration: 0.9)) {
           arrowNode.removeFromParent()
        }
        
        
    }
    
    func shootBurst(position: CGPoint){
        
        var arrows: [SKSpriteNode] = []
        
        for i in -2...2 {
        let arrowNode = SKSpriteNode(imageNamed: "cursor.png")
        arrowNode.size = CGSize(width: 17, height: 25)
            
        let piValue = Double(Double(i + 2) / 4.0) * Double.pi
            
        arrowNode.position = CGPoint(x: position.x + CGFloat(17 * i), y: position.y + CGFloat(sin(piValue)) * 30)
        arrowNode.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: "cursor.png"), size: CGSize(width: 17, height: 25))
       // arrowNode.physicsBody?.usesPreciseCollisionDetection = true
        arrowNode.physicsBody?.mass = 0
        arrowNode.physicsBody?.friction = 0
        arrowNode.zRotation = CGFloat( piValue * -1) + CGFloat(Double.pi / 4)
        arrowNode.physicsBody?.categoryBitMask = mouseBullet
        arrowNode.physicsBody?.contactTestBitMask = redPelletBitmask
        addChild(arrowNode)
        arrows.append(arrowNode)
        arrowNode.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 10000, dy: sin(piValue) * 10000))
            
        }
        for i in -2...2 {
            
            if(i != -2 && i != 2) {
                
            let arrowNode = SKSpriteNode(imageNamed: "cursor.png")
            arrowNode.size = CGSize(width: 17, height: 25)
            
            let piValue = Double(Double(i + 2) / 4.0) * Double.pi
            
            arrowNode.position = CGPoint(x: position.x + CGFloat(17 * i), y: position.y - CGFloat(sin(piValue)) * 30)
            arrowNode.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: "cursor.png"), size: CGSize(width: 17, height: 25))
            // arrowNode.physicsBody?.usesPreciseCollisionDetection = true
            arrowNode.physicsBody?.mass = 0
            arrowNode.physicsBody?.friction = 0
            arrowNode.zRotation =  CGFloat(piValue) + CGFloat(Double.pi / 4)
            arrowNode.physicsBody?.categoryBitMask = mouseBullet
            arrowNode.physicsBody?.contactTestBitMask = redPelletBitmask
            addChild(arrowNode)
            arrows.append(arrowNode)
             arrowNode.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 10000, dy: -sin(piValue) * 10000))
            }
        }
        
        self.run(SKAction.wait(forDuration: 1)) {
            for arrow in arrows {
                arrow.run(SKAction.fadeOut(withDuration: 0.2)) {
                    arrow.removeFromParent()
                }
            }
            arrows.removeAll()
        }
    
    }
    
    //EFFECTS
    
    func explode(position: CGPoint){
        
        let explosionParticle = SKEmitterNode(fileNamed: "explode.sks")
        explosionParticle?.position = position
        //explosionParticle?.shader = colorColumns
        //explosionParticle?.physicsBody?.affectedByGravity = true
        addChild(explosionParticle!)
        
        self.run(SKAction.wait(forDuration: 3)) {
            explosionParticle?.removeFromParent()
        }
        
    }
    
    func ringSuccess(position: CGPoint){
        
        let ringSuccessParticle = SKEmitterNode(fileNamed: "RingSuccess.sks")
        ringSuccessParticle?.position = position
        
        //explosionParticle?.shader = colorColumns
        //explosionParticle?.physicsBody?.affectedByGravity = true
        addChild(ringSuccessParticle!)
        
        self.run(SKAction.wait(forDuration: 0.5)) {
            ringSuccessParticle?.run(SKAction.fadeOut(withDuration: 1)) {
                ringSuccessParticle?.removeFromParent()
            }
        }
        
    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        
        if !isEditing{
        
       if (contact.bodyA.categoryBitMask == mouseBitmask) && (contact.bodyB.categoryBitMask == redPelletBitmask)
       {
        
        
        let pellet = contact.bodyB.node as! Pellet
        
        if pellet.stringID.range(of: "tutorial1") != nil {
            pelletTutorial1.removeValue(forKey: pellet.stringID)
        }
        
        if pellet.stringID.range(of: "tutorial2") != nil {
            pelletTutorial2.removeValue(forKey: pellet.stringID)
        }
            pellet.removeFromParent()
            pellets.removeValue(forKey: pellet.index)
            explode(position: pellet.position)
        if !isBruised{
            damageHealth(damageTaken: 10)
            startBruising()

        }
        
        }
        
        if (contact.bodyA.categoryBitMask == mouseBitmask) && (contact.bodyB.categoryBitMask == bluePelletBitmask)
        {
            SCORE += 10
            if !onBossScreen{
                updateCircleLightsSize(size: 4)
            }
            isBursting = true
            let pellet = contact.bodyB.node as! Pellet
            pellets.removeValue(forKey: pellet.index)
            pellet.removeFromParent()
            
        }
       
        
        if (contact.bodyA.categoryBitMask == mouseBitmask) && (contact.bodyB.categoryBitMask == greenPelletBitmask)
        {
            HEALTH += 10
            let scale = SKAction.scaleX(to: CGFloat(Double(HEALTH)/100.0), duration: 0.2)
            healthBar.run(scale)
            let pellet = contact.bodyB.node as! Pellet
            pellets.removeValue(forKey: pellet.index)
            pellet.removeFromParent()
            contact.bodyB.node?.removeFromParent()
            
        }
        if (contact.bodyA.categoryBitMask == mouseBullet) && (contact.bodyB.categoryBitMask == redPelletBitmask){
            
            SCORE += 1
            
            explode(position: (contact.bodyB.node?.position)!)
            
            contact.bodyA.node?.removeFromParent()
            let pellet = contact.bodyB.node as! Pellet
            
            if pellet.stringID.range(of: "tutorial1") != nil {
                pelletTutorial1.removeValue(forKey: pellet.stringID)
            }
            
            if pellet.stringID.range(of: "tutorial2") != nil {
                pelletTutorial2.removeValue(forKey: pellet.stringID)
            }
            
            pellets.removeValue(forKey: pellet.index)
            pellet.removeFromParent()
        }
        
        if ((contact.bodyA.categoryBitMask == yellowPelletBitmask) && (contact.bodyB.categoryBitMask == yellowPelletHole)) || ((contact.bodyB.categoryBitMask == yellowPelletBitmask) && (contact.bodyA.categoryBitMask == yellowPelletHole)){
            let pellet = contact.bodyA.node as! Pellet
            explode(position: pellet.position)
            ringSuccess(position: pellet.position)
            contact.bodyB.node?.removeFromParent()
            pellet.removeFromParent()
            pellets.removeValue(forKey: pellet.index)
            holesNotChecked = 0
            if pellet.stringID == "bossPellets"{
                
                bossHealth -= 100
                SCORE += 23
                
                for pellet in pellets {
                    explode(position: pellet.value.position)
                    pellet.value.removeFromParent()
                    pellets.removeAll()
                }
            }
        }
        
        if (contact.bodyA.categoryBitMask == mouseBullet) && (contact.bodyB.categoryBitMask == bossBitmask){
            explode(position: (contact.bodyA.node?.position)!)
            contact.bodyA.node?.removeFromParent()
            
            bossHealth -= 2
        }
            
        }
    
    }
    
    func resetScene(){
        
        isResetting = true
        
        
        bossAttacking = false
        holesNotChecked = 0
        
        bossNode.run(SKAction.fadeOut(withDuration: 0.4)) {
            bossNode.position = CGPoint(x: WIDTH/2, y: HEIGHT + 110)
        }
        
        arrowDirection = CGVector(dx: 0, dy: 10000)
        //middleShader.alpha = 0
        
        quickCut = {}
        lengthenTimeCheck = {}
        
        actionNode.removeAllActions()
        
        for ring in yellowRings {
            ring.removeFromParent()
        }
        
        yellowRings.removeAll()
        
       // currentActionsInSequence.removeAll()

        
        circleBack.position = mousePosLocal
        circleNode.position = mousePosLocal
        middleShader.position = mousePosLocal
        
        
        let speed: CGFloat = 5.0
        
        let scaleDownCircle = SKAction.customAction(withDuration: TimeInterval(speed),
                actionBlock: { (node, time) in
            
                    let nodeCircle = node as! Pellet
                    let currentRadius = nodeCircle.radius
                    let inverseTime = (speed - time)
                    let decreasingVal = CGFloat(currentRadius/Double(speed)) * inverseTime
                    nodeCircle.radius = Double(decreasingVal)
        })
        
        let unBlur = SKAction.customAction(withDuration: TimeInterval(speed)) { (node, elapsedTime) in
            let value = self.filter?.value(forKey: kCIInputRadiusKey) as! Double
            let inverseTime = (speed - elapsedTime)
            let decreasingVal = CGFloat(value/Double(speed)) * inverseTime
            self.filter?.setValue(decreasingVal, forKey: kCIInputRadiusKey)
        }
        
        actionNode.run(unBlur)
        circleBack.run(scaleDownCircle)
        circleNode.run(scaleDownCircle)
        middleShader.run(scaleDownCircle)
        
        self.run(SKAction.wait(forDuration: 1), completion:{
            isResetting = false
            circleNode.removeAllActions()
            self.actionNode.removeAllActions()
            self.circleBack.removeAllActions()
            self.middleShader.removeAllActions()

        })
        
        
        
        for pellet in pellets {
            pellet.value.removeFromParent()
        }
        
        for pellet in pelletTutorial1 {
            pellet.value.removeFromParent()
        }
        
        for pellet in pelletTutorial2 {
            pellet.value.removeFromParent()
        }
        
        pellets.removeAll()
        pelletTutorial1.removeAll()
        pelletTutorial2.removeAll()
        
        HEALTH = 100
        
        let scale = SKAction.scaleX(to: 0, duration: 0.2)
        healthBar.run(scale)
        
        
        onStartScreen = true
        
        pelletIndex = 2
        
        showDisplayMenu()

    }
    
    func pauseScene(){
        
        pauseScreen.run(SKAction.wait(forDuration: 0.1)) {
            let blurNode = SKEffectNode()
            self.filter?.setValue(20, forKey: kCIInputRadiusKey)
            blurNode.filter = self.blurPauseEffect
            self.physicsWorld.speed = 0.0
            self.blurPause.removeFromParent()
            self.pausedIcon.removeFromParent()
            self.pausedIcon.removeAllActions()
            self.addChild(self.blurPause)
            self.pauseScreen.removeAllActions()
            self.pauseScreen.removeFromParent()
            self.blurPause.addChild(self.pauseScreen)
            self.addChild(self.pausedIcon)
            self.pausedIcon.run(SKAction.wait(forDuration: 0.1)) {
                self.pausedIcon.run(SKAction.fadeIn(withDuration: 0.3))
                self.pausedIcon.run(SKAction.move(to: CGPoint(x: WIDTH/2, y:(HEIGHT/2)), duration: 0.3))
            }
            self.pauseScreen.run( SKAction.move(to: CGPoint(x: -15, y: HEIGHT), duration: 0.3))
            self.pauseScreen.run(SKAction.customAction(withDuration: 0.2, actionBlock: { (node, elapsedTime
                ) in
                let val = elapsedTime * 75
                self.blurPauseEffect?.setValue(val, forKey: kCIInputRadiusKey)
            }))
            
            setMessage(message: "Place Cursor on Screen to Resume",duration: 0)
        }
        
        actionNode.isPaused = true
    }
    
    func unpauseScene(){
        pauseScreen.removeAllActions()
        pausedIcon.removeAllActions()
        
        if !intentionalSlomo {
        self.physicsWorld.speed = 1.0
        }
        pauseScreen.run( SKAction.move(to: CGPoint(x: -15, y: -16), duration: 0.4))
        pauseScreen.run(SKAction.customAction(withDuration: 0.2, actionBlock: { (node, elapsedTime
            ) in
            let inverseTime = (0.2 - elapsedTime)
            let val = inverseTime * 75
            self.blurPauseEffect?.setValue(val, forKey: kCIInputRadiusKey)
        }))
        pausedIcon.run(SKAction.wait(forDuration: 0.1)) {
            self.pausedIcon.run(SKAction.fadeOut(withDuration: 0.3))
            self.pausedIcon.run(SKAction.move(to: CGPoint(x: WIDTH/2, y:(HEIGHT/2) - 50), duration: 0.3))
        }
        if currentMessage.isEmpty {
            viewOut()
        }else{
            setMessage(message: currentMessage, duration: 0)
        }
        
        actionNode.isPaused = false
    }
    
    func startBruising(){
        isBruised = true
        let wait = SKAction.wait(forDuration: 0.1)
        let changeBruiseFactor = SKAction.customAction(withDuration: 0.0) { (node, elapsedTime) in
            self.isBruised = false
        }
        
         let sequence = SKAction.sequence([wait, changeBruiseFactor])
            self.run(sequence)
    
    }
    
    
    func damageHealth(damageTaken: Int){
        HEALTH -= damageTaken
        let position = healthBar.position
        let scale = SKAction.scaleX(to: CGFloat(Double(HEALTH)/100.0), duration: 0.2)
        healthBar.run(scale)
        healthBar.position = position
    }
    
    
    //Red Pellets - Bad, Damage Player
    //Green Pellets - Good, Heal Player
    //Blue Pellets - Gives 10 second burst shooting
    //Purple Pellets - Boosts Score
    //Yellow Pellets - Pairing System (Mouse has to guide pellet to hole/other node)
    
    func introRedPellets(){
        
        for i in 1...10{
             let pellet = addRedPellet(position: CGPoint(x: i * 64, y: HEIGHT))
            let pellet2 = addRedPellet(position: CGPoint(x: i * 64, y: 0))

            pellets[pellet.index] = pellet
            pellets[pellet2.index] = pellet2

        }
        
    }
    
    func introShooting(){
        for i in 0...2{
            let pellet1 = addRedPellet(position: CGPoint(x: (WIDTH / 2) + (i * 50), y: (HEIGHT / 4) * 3))
            let pellet2 = addRedPellet(position: CGPoint(x: (WIDTH / 2) - (i * 50), y: (HEIGHT / 4) * 3))
            
            pellet1.stringID = "tutorial1:\(i)"
            pellet2.stringID = "tutorial1:\(i + 5)"
            
            pelletTutorial1[pellet1.stringID] = pellet1
            pelletTutorial1[pellet2.stringID] = pellet2
        }
    }
    
    func introBluePellets(){
        var _ = addBluePellet(position: CGPoint(x: 0, y: 0))

    }
    
    func introGreenPellets(){
        for _ in 1...3 {
            let pellet = addGreenPellet(position: CGPoint(x: CGFloat(arc4random_uniform(UInt32(WIDTH - 100))) + CGFloat(50), y: CGFloat(arc4random_uniform(UInt32(HEIGHT - 100))) + CGFloat(50)))
            pellets[pellet.index] = pellet
        }
       
    }
    
    func introDirection(){
        for i in 1...15{
            let pellet = addRedPellet(position: CGPoint(x: i * 42, y: HEIGHT))
            let pellet2 = addRedPellet(position: CGPoint(x: i * 42, y: 0))
            
            pellet.stringID = "tutorial2:\(i)"
            pellet2.stringID =  "tutorial2:\(i + 100)"
            
            pelletTutorial2[pellet.stringID] = pellet
            pelletTutorial2[pellet2.stringID] = pellet2

            
            
        }
        
        for i in 1...10{
            let pellet = addRedPellet(position: CGPoint(x:0, y:  i * 48))
            let pellet2 = addRedPellet(position: CGPoint(x: WIDTH, y:  i * 48))
            
            pellet.stringID = "tutorial2:\(i + 200)"
            pellet2.stringID =  "tutorial2:\(i + 300)"
           
            pelletTutorial2[pellet.stringID] = pellet
            pelletTutorial2[pellet2.stringID] = pellet2
            
            
        }
    }
    
    func introBurst(){
        
        for i in 1...15{
            let pellet = addRedPellet(position: CGPoint(x: i * 42, y: HEIGHT))
            let pellet2 = addRedPellet(position: CGPoint(x: i * 42, y: 0))
            
            pellets[pellet.index] = pellet
            pellets[pellet2.index] = pellet2
            
            
        }
        
        for i in 1...10{
            let pellet = addRedPellet(position: CGPoint(x:0, y:  i * 48))
            let pellet2 = addRedPellet(position: CGPoint(x: WIDTH, y:  i * 48))
            
            pellets[pellet.index] = pellet
            pellets[pellet2.index] = pellet2
            
            
        }
        
    }
    
    
    //Starts Boss
    func createAndStartBoss(boss: Boss, shader: SKShader){
        
        bossNode.removeAllActions()
        bossNode.alpha = 1
        bossNode.fillShader = shader
        
        bossHealth = Int(boss.health)
        bossStrength = Int(boss.attackDamage)
        bossNode.run(SKAction.move(to: CGPoint(x: WIDTH/2, y: HEIGHT/2), duration: 1.0)) {
            setMessage(message: "Bosses are harder to kill", duration: 0)
        }
        actionNode.run(SKAction.wait(forDuration: 5)) {
           
            viewOut()
        }
        
        actionNode.run(SKAction.wait(forDuration: 6)) {
            self.startAttacking()
          
        }
    }
    
    func startAttacking() {
        if !bossAttacking {
            return
        }
        
        let randSelect = arc4random_uniform(5)
        var duration = 7
        
        switch randSelect {
        case 0:
            explodeBossAttack()
            duration = 6
        case 1:
            bossExplodeAttackBurst()
            duration = 3
        case 2:
            armorBossDefenseAttack()
            duration = 5
        case 3:
            bossExplodeAttackGreenPellets()
            duration = 7
        case 4:
            addBossYellowPellets()
        default:
            explodeBossAttack()
        }
        
        actionNode.run(SKAction.wait(forDuration: TimeInterval(duration))) {
            self.startAttacking()
        }
        
    }
    
    func explodeBossAttack(){
        bossNode.run(SKAction.scale(by: 0.8, duration: 0.3)) {
            self.actionNode.run(SKAction.wait(forDuration: 0.2), completion: {
                bossNode.run(SKAction.scale(by: 1.2, duration: 0.1), completion: {
                    
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        
                        let pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))

                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet

                        
                    }
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        
                        let pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y - CGFloat(sin(piValue)) * 105 - CGFloat(30)))
                        
                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: -sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet
                        
                    }
                })
            })
            
        }
    }
    
    
    func armorBossDefenseAttack(){
        bossNode.run(SKAction.scale(by: 0.8, duration: 0.3)) {
            self.actionNode.run(SKAction.wait(forDuration: 0.2), completion: {
                bossNode.run(SKAction.scale(by: 1.3, duration: 0.1), completion: {
                    
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        
                        let pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                        
                        
                       // pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: sin(piValue) * 100))
                        
                        pellet.stringID = "noPull"
                        pellets[pellet.index] = pellet
                        
                    }
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        
                        let pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y - CGFloat(sin(piValue)) * 105 - CGFloat(30)))
                        
                        
                       // pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: -sin(piValue) * 100))
                        
                        pellet.stringID = "noPull"
                        
                        pellets[pellet.index] = pellet

                    }
                })
            })
            
        }
    }
    
    
    func bossExplodeAttackBurst(){
        bossNode.run(SKAction.scale(by: 0.8, duration: 0.3)) {
            self.actionNode.run(SKAction.wait(forDuration: 0.2), completion: {
                bossNode.run(SKAction.scale(by: 1.3, duration: 0.1), completion: {
                    
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        var pellet: Pellet!
                        
                        if i == 3{
                              pellet = self.addBluePellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                        }else{
                             pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                            
                        }
                      
                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet

                        
                    }
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        
                        let pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y - CGFloat(sin(piValue)) * 105 - CGFloat(30)))
                        
                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: -sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet

                        
                    }
                })
            })
            
        }
    }
    
    func bossExplodeAttackGreenPellets(){
        bossNode.run(SKAction.scale(by: 0.8, duration: 0.3)) {
            self.actionNode.run(SKAction.wait(forDuration: 0.2), completion: {
                bossNode.run(SKAction.scale(by: 1.3, duration: 0.1), completion: {
                    
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        var pellet: Pellet!
                        
                        if i == 3{
                            pellet = self.addGreenPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                        }else{
                            pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                            
                        }
                        
                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet
                        
                        
                    }
                    
                    for i in -4...4 {
                        let piValue = Double(Double(i + 4) / 8.0) * Double.pi
                        
                        var pellet: Pellet!
                        
                        if i == 3{
                            pellet = self.addGreenPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                        }else{
                            pellet = self.addRedPellet(position: CGPoint(x: bossNode.position.x + CGFloat(25 * i), y: bossNode.position.y + CGFloat(sin(piValue)) * 105 + CGFloat(15)))
                            
                        }
                        
                        
                        pellet.physicsBody?.applyForce(CGVector(dx: -cos(piValue) * 100, dy: -sin(piValue) * 100))
                        
                        pellets[pellet.index] = pellet
                        
                        
                    }
                })
            })
            
        }
    }
    
    func addBossYellowPellets() {
        
        
        
        let pellet = self.addYellowPellet(position: CGPoint(x: CGFloat(arc4random_uniform(UInt32(WIDTH - 100)) + 50), y: 100), holePosition: CGPoint(x: CGFloat(arc4random_uniform(UInt32(WIDTH - 100)) + 50), y: 390))
        pellet.stringID = "bossPellets"
        pellets[pellet.index] = pellet
    }
    
    
    //Randoms
    
    func createRandomRedPellets(){
        for _ in 1...25{
            let pellet = addRedPellet(position: CGPoint(x: CGFloat(arc4random_uniform(540) + 50), y: CGFloat(arc4random_uniform(380) + 50)))
            pellets[pellet.index] = pellet
        }
    }
    
    func createRandomBluePellet(){
        let pellet = addBluePellet(position: CGPoint(x: CGFloat(arc4random_uniform(540) + 50), y: CGFloat(arc4random_uniform(380) + 50)))
        pellets[pellet.index] = pellet
    }
    
    func createRandomGreenPellets(){
        for _ in 1...5 {
            let pellet = addGreenPellet(position: CGPoint(x: CGFloat(arc4random_uniform(540) + 50), y: CGFloat(arc4random_uniform(380) + 50)))
            pellets[pellet.index] = pellet

        }

    }
    
    //Create Tutorial Level
    func createTutorialLevel() -> Level {
        let level = Level()
        
        level.name = "Tutorial"
        level.screenshot = #imageLiteral(resourceName: "tutorialScreenshot.png")
        
        //Create Sequences For Tutorial Level
        
        let sequence1 = Sequence()
        sequence1.action = {
            self.introShooting()
        }
        sequence1.quickCut = {
            if(pelletTutorial1.isEmpty){
               // self.needsLengthening = false
                
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }

            }
        }
        sequence1.lengthenTimeCheck = {
            if !pelletTutorial1.isEmpty {
                self.needsLengthening = true
                self.neededLengthening = true
            }
        }
        sequence1.message = "Click or hold to Shoot"
        sequence1.messageDuration = 0
        sequence1.duration = 1
        sequence1.name = "sequence1"
        level.sequences.append(sequence1)
        
        let sequence2 = Sequence()
        sequence2.action = {
            self.introDirection()
        }
        sequence2.quickCut = {
            if pelletTutorial2.count < 10 {
                self.quickCut = {}
                
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        sequence2.messageDuration = 0
        sequence2.message = "Use arrow keys or WASD to change direction of shooting"
        sequence2.duration = 17
        sequence2.name = "sequence2"
        level.sequences.append(sequence2)
        
        let removeTutorial1Pellets = Sequence()
        removeTutorial1Pellets.action = {
            for pellet in pelletTutorial2{
                self.explode(position: pellet.value.position)
                pelletTutorial2.removeValue(forKey: pellet.key)
                pellet.value.removeFromParent()
            }
        }
        removeTutorial1Pellets.messageDuration = 0
        removeTutorial1Pellets.message = ""
        removeTutorial1Pellets.duration = 1
        removeTutorial1Pellets.name = "removeTutorial1Pellets"
        level.sequences.append(removeTutorial1Pellets)
        
        let sequence3 = Sequence()
        sequence3.action = {
            self.introRedPellets()
        }
        sequence3.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
        sequence3.messageDuration = 0
        sequence3.message = "Avoid or Shoot Red Pellets"
        sequence3.duration = 10
        sequence3.name = "sequence3"
        level.sequences.append(sequence3)
        
        let removePellets = Sequence()
        removePellets.action = {
            for pellet in pellets{
                self.explode(position: pellet.value.position)
                pellets.removeValue(forKey: pellet.key)
                pellet.value.removeFromParent()
            }
        }
        removePellets.messageDuration = 0
        removePellets.message = ""
        removePellets.duration = 1
        removePellets.name = "removePellets"
        level.sequences.append(removePellets)
        
        let sequence4 = Sequence()
        sequence4.action = {
            self.introGreenPellets()
            
            if HEALTH > 50 {
                self.damageHealth(damageTaken: 20)
            }
        }
        sequence4.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
//        sequence4.lengthenTimeCheck = {
//            if !pellets.isEmpty {
//                self.needsLengthening = true
//                self.neededLengthening = true
//            }
//        }
        sequence4.messageDuration = 0
        sequence4.message = "Green Pellets Heal You"
        sequence4.duration = 10
        sequence4.name = "sequence4"
        level.sequences.append(sequence4)
        
        let sequence5 = Sequence()
        sequence5.action = {
            self.introBurst()
            let bluePellet = self.addBluePellet(position: CGPoint(x: CGFloat(arc4random_uniform(240) + 200), y: CGFloat(arc4random_uniform(280) + 100)))
            
            
            self.actionNode.run(SKAction.wait(forDuration: 0.5)) {
                self.intentionalSlomo = true
                    pellets[bluePellet.index] = bluePellet
                self.actionNode.run(SKAction.customAction(withDuration: 1.2, actionBlock: { (node, elapsedTime) in
                    self.physicsWorld.speed = (1.2 - elapsedTime) + 0.03
                }))
                setMessage(message: "Blue pellets allow you to shoot in bursts", duration: 0)
                self.currentMessage = "Blue pellets allow you to shoot in bursts"
            }
        }
        
        sequence5.quickCut = {

            if self.bluePelletExists == false && self.isHolding{
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
//        sequence5.lengthenTimeCheck = {
//            if !pellets.isEmpty {
//                self.needsLengthening = true
//                self.neededLengthening = true
//            }
//        }
        
        sequence5.messageDuration = 0
        sequence5.message = ""
        sequence5.duration = 10
        sequence5.name = "sequence5"
        level.sequences.append(sequence5)
        
        
        let speedUpWorld = Sequence()
        speedUpWorld.action = {
           self.physicsWorld.speed = 1.0
            self.intentionalSlomo = false
        }
        speedUpWorld.messageDuration = 0
        speedUpWorld.message = ""
        speedUpWorld.duration = 5
        speedUpWorld.name = "speedUpWorld"
        level.sequences.append(speedUpWorld)
        
        
        let sequence6 = Sequence()
        sequence6.action = {
            let pellet = self.addYellowPellet(position: CGPoint(x: 100, y: HEIGHT/2), holePosition: CGPoint(x: 540, y: HEIGHT/2))
            pellets[pellet.index] = pellet
        }
        sequence6.quickCut = {
            if self.holesNotChecked == 0 {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
//        sequence6.lengthenTimeCheck = {
//            if self.holesNotChecked != 0 {
//                self.needsLengthening = true
//                self.neededLengthening = true
//            }
//        }
        sequence6.messageDuration = 0
        sequence6.message = "Guide Yellow Pellets to their holes"
        sequence6.duration = 20
        
        sequence6.name = "sequence6"
        level.sequences.append(sequence6)
        
        let boss = Boss()
        boss.health = 650
        
        let bossFight = Sequence()
        bossFight.action = {
            self.onBossScreen = true
           self.createAndStartBoss(boss: boss, shader: self.blobShader)
            self.updateCircleLightsSize(size: 1)
            bossAttacking = true
        }
        bossFight.quickCut = {
            if bossHealth < 0 {
                self.onBossScreen = false
                bossAttacking = false
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
        //        sequence6.lengthenTimeCheck = {
        //            if self.holesNotChecked != 0 {
        //                self.needsLengthening = true
        //                self.neededLengthening = true
        //            }
        //        }
        bossFight.messageDuration = 5
        bossFight.message = ""
        bossFight.duration = 2
        bossFight.background?.shaderBack = ringShader
        bossFight.name = "bossFight"
        level.sequences.append(bossFight)
        
        
        return level
    }
    
    
    func createLevel1() -> Level{
        let level = Level()
        
        
        let introSequence = Sequence()
        introSequence.message = "Backgrounds make it hard to see pellets"
        introSequence.background = Background(shader: colorBlob)
        introSequence.duration = 3
        level.sequences.append(introSequence)
        
        level.name = "Level 1"
        level.screenshot = #imageLiteral(resourceName: "level1ScreenShot.png")
        
        let sequence1 = Sequence()
        
        sequence1.action = {
            self.createRandomRedPellets()
        }
        sequence1.background = Background(shader: colorBlob)
        sequence1.duration = 10
        sequence1.message = "Backgrounds make it hard to see pellets"
        sequence1.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence1)
        
        
        let sequence2 = Sequence()
        
        sequence2.action = {
            self.createRandomRedPellets()
            self.createRandomBluePellet()
        }
        sequence2.background = Background(shader: colorBlob)
        sequence2.duration = 3
        sequence2.message = ""
        sequence2.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence2)
        
        let sequence3 = Sequence()
        
        sequence3.action = {
            self.createRandomGreenPellets()
        }
        sequence3.background = Background(shader: colorBlob)
        sequence3.duration = 4
        sequence3.message = ""
        sequence3.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence3)
        
        let sequence4 = Sequence()
        
        sequence4.action = {
            self.createRandomRedPellets()
        }
        sequence4.background = Background(shader: colorBlob)
        sequence4.duration = 10
        sequence4.message = ""
        sequence4.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence4)
        
        let bossFight = Sequence()
        
        let boss = Boss()
        boss.health = 750
        
        bossFight.action = {
            self.onBossScreen = true
            self.createAndStartBoss(boss: boss, shader: self.radial)
            self.updateCircleLightsSize(size: 1)
            bossAttacking = true
        }
        bossFight.quickCut = {
            if bossHealth < 0 {
                self.onBossScreen = false
                bossAttacking = false
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
        bossFight.background = Background(shader: colorBlob)
        bossFight.duration = 5
        bossFight.message = ""
        level.sequences.append(bossFight)
        
        
        return level
    }
    
    func createLevel2() -> Level{
        let level = Level()
        
        
        let introSequence = Sequence()
        introSequence.message = "Good Luck! (You'll Need it)"
        introSequence.background = Background(shader: colorBlob)
        introSequence.duration = 3
        level.sequences.append(introSequence)
        
        level.name = "Level 2"
        level.screenshot = #imageLiteral(resourceName: "level2.png")
        
        let sequence1 = Sequence()
        
        sequence1.action = {
            self.createRandomRedPellets()
        }
        sequence1.background = Background(shader: colorSwirl)
        sequence1.duration = 10
        sequence1.message = ""
        sequence1.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence1)
        
        let sequence2 = Sequence()
        
        sequence2.action = {
            self.createRandomRedPellets()
            self.createRandomBluePellet()
        }
        sequence2.background = Background(shader: ringShader)
        sequence2.duration = 3
        sequence2.message = ""
        sequence2.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence2)
        
        let sequence3 = Sequence()
        
        sequence3.action = {
            self.createRandomRedPellets()
        }
        sequence3.background = Background(shader: radial)
        sequence3.duration = 10
        sequence3.message = ""
        sequence3.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence3)
        
        let sequence4 = Sequence()
        
        sequence4.action = {
            self.createRandomRedPellets()
            self.createRandomGreenPellets()
        }
        sequence4.background = Background(shader: coloredLights)
        sequence4.duration = 10
        sequence4.message = ""
        sequence4.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence4)
        
        let sequence5 = Sequence()
        
        sequence5.action = {
            self.createRandomRedPellets()
        }
        sequence5.background = Background(shader: radial)
        sequence5.duration = 2
        sequence5.message = ""
        sequence5.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence5)
        
        
        
        let sequence6 = Sequence()
        
        sequence6.action = {
            self.createRandomBluePellet()
        }
        sequence6.background = Background(shader: colorSwirl)
        sequence6.duration = 2
        sequence6.message = ""
        sequence6.quickCut = {
            if pellets.isEmpty {
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        level.sequences.append(sequence6)
        
        
        let bossFight = Sequence()
        
        let boss = Boss()
        boss.health = 2000
        
        bossFight.action = {
            self.onBossScreen = true
            self.createAndStartBoss(boss: boss, shader: self.colorColumns)
            self.updateCircleLightsSize(size: 1)
            bossAttacking = true
        }
        bossFight.quickCut = {
            if bossHealth < 0 {
                self.onBossScreen = false
                bossAttacking = false
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
        bossFight.background = Background(shader: colorSwirl)
        bossFight.duration = 5
        bossFight.message = ""
        level.sequences.append(bossFight)
        
        
        return level
    }
    
    func createFinalBoss() -> Level{
        
        let level = Level()
        
        level.name = "Final Bossfight"
        level.screenshot = #imageLiteral(resourceName: "finalBoss.png")
        
        let introSequence = Sequence()
        introSequence.duration = 3
        introSequence.message = "This is the final boss!"
        
        introSequence.background = Background(shader: colorSwirl)
        
        level.sequences.append(introSequence)

        
        let bossFight = Sequence()
        
        
        
        let boss = Boss()
        boss.health = 10000
        
        bossFight.action = {
            self.onBossScreen = true
            self.createAndStartBoss(boss: boss, shader: self.colorBlob)
            self.updateCircleLightsSize(size: 1)
            bossAttacking = true
        }
        bossFight.quickCut = {
            if bossHealth < 0 {
                self.onBossScreen = false
                bossAttacking = false
                self.quickCut = {}
                if !isResetting{
                    self.nextAction()
                }
            }
        }
        
        bossFight.background = Background(shader: ringShader)
        bossFight.duration = 5
        bossFight.message = ""
        level.sequences.append(bossFight)
        
        
        
        return level
    }
    
    
    func loadLevel(level: Level) {
    
        HEALTH = 100
        SCORE = 0
        
        healthlabelOnScreen.alpha = 1
        
        physicsWorld.speed = 1
        arrowDirection = CGVector(dx: 0, dy: 10000)
        
        var actions: [SKAction] = []
        for sequence in level.sequences{
            let actionSequence = SKAction.customAction(withDuration: 0.0, actionBlock: { (node, elapsedTime) in
                sequence.action()
                setMessage(message: sequence.message, duration: Int(sequence.messageDuration))
                self.currentMessage = sequence.message
                if self.currentMessage.isEmpty{
                    viewOut()
                    
                }
                if sequence.name == "tested"{
                    self.actionNode.run(SKAction.wait(forDuration: 0.5), completion: {
                        self.quickCut = sequence.quickCut
                    })
                }else{
                    self.quickCut = sequence.quickCut

                }
                self.lengthenTimeCheck = sequence.lengthenTimeCheck
                self.middleShader.fillShader = sequence.background?.shaderBack
            })
            actions.append(actionSequence)
            let waitSequence = SKAction.wait(forDuration: TimeInterval(sequence.duration))
            actions.append(waitSequence)
        }
        
        //Action that moves to next level (or Win Screen Depending on where you are at)
        let moveToNextLevel = SKAction.customAction(withDuration: 0.0) { (node, elapsedTime) in
            //self.nextLevel()
        }
        
        actions.append(moveToNextLevel)
        
        if !isResetting {
            runActions(actions: actions)
        }
        
         arrowDirection = CGVector(dx: 0, dy: 20000)

    }
    
    // Instead of running the actions through the sequence, I run it recursively, as it gives me the ability to include completion handlers after every action, and not just the sequence. If you are reading this comment, could you email me at me@jonathonderr.com how much of a waste this function is? I would like confirmation. Thanks. :)
    func runActions(actions: [SKAction]){
        
        if needsLengthening {
            return
        } else if !isResetting{
            if actions.isEmpty {return}
            
            actionNode.run(actions[0]) {
                var actionsRemoved = actions
                
                actionsRemoved.removeFirst()
                self.currentActionsInSequence = actionsRemoved
                if !isResetting{
                self.runActions(actions: actionsRemoved)
                    
                }
            }
        }
        
    }
    
    func nextAction(){
        
        
        if currentActionsInSequence.isEmpty {
            winScreenAct()
            return
        }
        actionNode.removeAllActions()
        if !needsLengthening{
            currentActionsInSequence.removeFirst()

        }
        needsLengthening = false
        if !isResetting{
            runActions(actions: currentActionsInSequence)

        }
    }
    
    func nextLevel(){
        resetScene()
    }
    
    func checkExistingBluePellets() -> Bool{
        var noPellets = true
        
        for pellet in pellets{
            
            let pelletMutable = pellet.value as! Pellet
            if pelletMutable.stringID == "BLUEPELLET" {
                noPellets = false
            }
        }
        
        return !noPellets
    }
    
    func winScreenAct(){
        
       onWinScreen = true
        
        self.scene?.physicsWorld.speed = 0.5
        
        actionNode.run(SKAction.wait(forDuration: 0.5)) {
            bossNode.run(SKAction.fadeOut(withDuration: 0.5)) {
                bossNode.position = CGPoint(x: WIDTH/2, y: HEIGHT + 110)
            }
            
            
            for pellet in pellets{
                self.explode(position: pellet.value.position)
                pellet.value.removeFromParent()
            }
            
            
            pellets.removeAll()
        }
        
        actionNode.run(SKAction.wait(forDuration: 1.5)) {
            winScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: HEIGHT), duration: 0.7))
            
            self.actionNode.run(SKAction.wait(forDuration: 0.6), completion: {
                showWinScreen(score: SCORE, health: HEALTH)

            })

        }
        
    }
    
    
    func loseScreenAct() {
        
        onLossScreen = true
        isResetting = true

        
        self.scene?.physicsWorld.speed = 0.5
        
        actionNode.run(SKAction.wait(forDuration: 0.5)) {
            bossNode.run(SKAction.fadeOut(withDuration: 0.5)) {
                bossNode.position = CGPoint(x: WIDTH/2, y: HEIGHT + 110)
            }
            
            
            for pellet in pellets{
                self.explode(position: pellet.value.position)
                pellet.value.removeFromParent()
            }
            
            for pellet in pelletTutorial1{
                self.explode(position: pellet.value.position)
                pellet.value.removeFromParent()
            }
           
            for pellet in pelletTutorial2{
                self.explode(position: pellet.value.position)
                pellet.value.removeFromParent()
            }
            
            pellets.removeAll()
            pelletTutorial1.removeAll()
            pelletTutorial2.removeAll()
        }
        
        actionNode.run(SKAction.wait(forDuration: 0.0)) {
            lossScreenBack.run(SKAction.move(to: CGPoint(x: 0, y: HEIGHT), duration: 0.3))
            
            self.actionNode.run(SKAction.wait(forDuration: 0.2), completion: {
                showLossScreen(score: SCORE, health: HEALTH)
                
            })
            
        }
    }
    
    
    func playLevel(level: Level) {
        
        if onStartScreen && !isResetting && !isOnLevelMenu{
            middleShader.alpha = 1

            filter?.setValue(0, forKey: kCIInputRadiusKey)
            let scaleCircle = SKAction.customAction(withDuration: 1.5) { (node, elapsedTime) in
                let node = node as! Pellet
                node.radius = node.radius + 15
            }
            let changeBlur = SKAction.customAction(withDuration: 1.5) { (node, elapsedTime) in
                self.filter?.setValue(elapsedTime * 40, forKey: kCIInputRadiusKey)
            }
            let changeBlurExisting = SKAction.customAction(withDuration: 0.5) { (node, elapsedTime) in
                self.filter?.setValue(elapsedTime * 40, forKey: kCIInputRadiusKey)
                self.filter?.setValue(self.filter?.value(forKey: kCIInputRadiusKey) as! Double + 3, forKey: kCIInputRadiusKey)
            }
            if circleNode.radius == 0 {
                
                circleNode.run(scaleCircle)
                circleBack.run(scaleCircle)
                circleNode.run(changeBlur)
                middleShader.run(scaleCircle)
            }else{
                
                circleNode.run(scaleCircle)
                circleBack.run(scaleCircle)
                circleNode.run(changeBlurExisting)
                middleShader.run(scaleCircle)
            }
            onStartScreen = false
            loadLevel(level: level)
            hideDisplayMenu()
            let scale = SKAction.scaleX(to: 1, duration: 0.2)
            middleShader.alpha = 1
            healthBar.run(scale)
            //viewOut()
            
        }else if !isResetting{
            //        explode(position: event.location(in: self))
            //        shootSingle(position: event.location(in: self))
            
        }
    }
    
    func updateCircleLightsSize(size: Float){
        
        let backgroundSize = vector2(Float(WIDTH), Float(HEIGHT))
        circleSize = size
        
        for shader in shaders{
            shader.uniforms = [
                SKUniform(name: "resolution", vectorFloat2: backgroundSize),
                SKUniform(name: "positionMouse", vectorFloat2: clampedGLSLMousePos),
                SKUniform(name: "touchbarColor", vectorFloat3: vector3(1.0, 1.0, 1.0)),
                SKUniform(name: "circleSize", float: Float(circleSize)),
                SKUniform(name: "speedGlobal", float: Float(shaderSpeed))
            ]
        }
        
    }
    

}


public func updateCircleColorAttributes(color: CIColor){
   // let mousePosition = vector2(Float(-1 * (mousePos?.x)!), Float((mousePos?.y)!))
    let backgroundSize = vector2(Float(WIDTH), Float(HEIGHT))
    let color = vector3(Float(color.red), Float(color.green), Float(color.blue))
    
    for shader in shaders{
        shader.uniforms = [
            SKUniform(name: "resolution", vectorFloat2: backgroundSize),
            SKUniform(name: "positionMouse", vectorFloat2: clampedGLSLMousePos),
            SKUniform(name: "touchbarColor", vectorFloat3: color),
            SKUniform(name: "circleSize", float: Float(circleSize)),
            SKUniform(name: "speedGlobal", float: Float(shaderSpeed))
        ]
    }
    
    
}




public class Pellet: SKShapeNode{
    
    var index: Int = 0
    //Use for tutorials (Could possibly be used later, but right now, I am using it for the tutorial ids [The pellets aren't attracted to the mouses gravity])
    var stringID: String = ""
    
    var radius: Double {
        didSet{
            self.path = Pellet.path(radius: self.radius)
        }
    }
    
    init(radius: Double, position: CGPoint) {
        self.radius = radius
        
        super.init()
        
        self.path = Pellet.path(radius: self.radius)
        self.position = position
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    class func path(radius: Double) -> CGMutablePath {
        let path: CGMutablePath = CGMutablePath()
        path.addArc(center: CGPoint.zero, radius: CGFloat(radius), startAngle: 0.0, endAngle: CGFloat(2.0 * Double.pi), clockwise: false)
        return path
    }

}


